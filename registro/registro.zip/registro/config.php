<?php
$db_host     = 'localhost';
$db_username = 'admin_mcutool';
$db_password = '6TUtel1jcA';
$db_name     = 'admin_mcutool';

/* EOF */