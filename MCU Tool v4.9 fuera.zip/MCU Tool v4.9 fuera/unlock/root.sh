#!/system/bin/sh

# voidstar and elliwigy

echo /data/local/tmp/unlock/remount2.sh > /sys/kernel/uevent_helper # schedule mounting system as read-write

echo "Please wait..."

sleep 10 # wait for the scheduled task to run

echo "Rooting..."

cp /data/local/tmp/unlock/install-recovery.sh /system/etc/install-recovery.sh
chmod 0755 /system/etc/install-recovery.sh
chcon u:object_r:toolbox_exec:s0 /system/etc/install-recovery.sh
ln -s /system/etc/install-recovery.sh /system/bin/install-recovery.sh 

mkdir /system/.ext
touch /system/.ext/.su
cp /data/local/tmp/unlock/su /system/xbin/su
cp /data/local/tmp/unlock/su /system/xbin/daemonsu
cp /data/local/tmp/unlock/su /system/xbin/sugote
chmod 0755 /system/xbin/su
chmod 0755 /system/xbin/daemonsu
chmod 0755 /system/xbin/sugote
chcon u:object_r:system_file:s0 /system/xbin/su
chcon u:object_r:system_file:s0 /system/xbin/daemonsu
chcon u:object_r:zygote_exec:s0 /system/xbin/sugote

cp /data/local/tmp/unlock/supolicy /system/xbin/supolicy
chmod 0755 /system/xbin/supolicy
chcon u:object_r:system_file:s0 /system/xbin/supolicy

cp /data/local/tmp/unlock/libsupol.so /system/lib64/libsupol.so
chmod 0644 /system/lib64/libsupol.so
chcon u:object_r:system_file:s0 /system/lib64/libsupol.so

cp /system/bin/sh /system/xbin/sugote-mksh
chmod 0755 /system/xbin/sugote-mksh
chcon u:object_r:system_file:s0 /system/xbin/sugote-mksh

cp /system/bin/app_process /system/bin/app_process_original
cp /system/bin/app_process64 /system/bin/app_process64_original
cp /system/bin/app_process64 /system/bin/app_process_init
chmod 0755 /system/bin/app_process_original
chmod 0755 /system/bin/app_process64_original
chmod 0755 /system/bin/app_process_init
chcon u:object_r:zygote_exec:s0 /system/bin/app_process64_original
chcon u:object_r:system_file:s0 /system/bin/app_process_init
rm /system/bin/app_process
ln -s /system/xbin/daemonsu /system/bin/app_process
rm /system/bin/app_process64
ln -s /system/xbin/daemonsu /system/bin/app_process64

sync
./system/xbin/su --install
reboot
