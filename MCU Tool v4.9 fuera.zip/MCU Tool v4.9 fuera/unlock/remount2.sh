#!/system/bin/sh



/system/bin/mount -o rw,remount /system

/system/bin/mount -o rw,remount /

/system/bin/mount -o rw,remount /efs

/system/bin/mount -o rw,remount /persist

/system/bin/mount -o rw,remount /dev

/system/bin/mount -o rw,remount /firmware

/system/bin/mount -o rw,remount /sys

/system/bin/mount -o rw,remount /cache

/system/bin/mount -o rw,remount /dsp

/system/bin/mount -o rw,remount /data

/system/bin/mount -o rw,remount /mnt

/system/bin/mount -o rw,remount /proc

/system/bin/mount -o rw,remount /sbin

/system/bin/mount -o rw,remount /etc

/system/bin/mount -o rw,remount /su

/system/bin/echo u:r:init:s0 > /proc/self/attr/current

/system/bin/echo u:r:init:s0 > /proc/self/attr/exec

exit
