﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 16/05/2020
 * Time: 01:02-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
// MyClass.h
#pragma once
using namespace System;

namespace cdmadev {
	/// <summary>
	///
	/// </summary>
	public ref class MyClass {
		// TODO: Add class methods here
	};
}
