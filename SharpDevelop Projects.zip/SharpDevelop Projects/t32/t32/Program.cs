﻿/*
 * Created by SharpDevelop.
 * User: HOME
 * Date: 3/19/2020
 * Time: 2:58 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;

namespace t32
{
	class Program
	{
		public static void Main(string[] args)
		{
			var text2 = Console.ReadLine();
			if (text2.Contains("0000000000000a00000006000000"))
				{
					string text3 = ConversionUtils.HexString2Ascii(Regex.Split(text2, "0000000000000a00000006000000")[1].Substring(0, 12));
					Console.WriteLine("MSL/SPC Code: " + text3);
				}
				else
				{
					Console.WriteLine("Read MSL/SPC Code: FAIL...!!!");
				}
			Console.WriteLine("Done!");
			Console.ReadKey(true);
		}
	}
	
	public class ConversionUtils
	{
		public static byte[] HexStringToBytes(string strInput)
		{
			checked
			{
				byte[] result;
				try
				{
					int num = 0;
					int num2 = 0;
					byte[] array = new byte[(int)Math.Round(unchecked((double)strInput.Length / 2.0 - 1.0)) + 1];
					while (strInput.Length > num + 1)
					{
						long value = Convert.ToInt64(strInput.Substring(num, 2), 16);
						array[num2] = Convert.ToByte(value);
						num += 2;
						unchecked
						{
							num2++;
						}
					}
					result = array;
				}
				catch (Exception)
				{
					Interaction.MsgBox("Hex String To Byte Array Conversion Error!", MsgBoxStyle.Critical, null);
					result = null;
				}
				return result;
			}
		}
		
		public static string GetASCIIString(string hexString)
		{
			string result;
			try
			{
				string text = "";
				int num = checked(hexString.Length - 1);
				for (int i = 0; i <= num; i++)
				{
					if (Operators.CompareString(hexString.Substring(i, 2), "00", false) != 0)
					{
						text += hexString.Substring(i, 2);
						i++;
					}
					else
					{
						i++;
					}
				}
				string text2 = "";
				while (text.Length > 0)
				{
					text2 += Convert.ToChar(Convert.ToUInt64(text.Substring(0, 2), 16)).ToString();
					text = text.Substring(2, checked(text.Length - 2));
				}
				result = text2;
			}
			catch (Exception)
			{
				result = "-1";
			}
			return result;
		}
		
		public static string HexString2Ascii(string hexString)
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i <= hexString.Length - 2; i += 2)
			{
				stringBuilder.Append(Convert.ToString(Convert.ToChar(int.Parse(hexString.Substring(i, 2), NumberStyles.HexNumber))));
			}
			return stringBuilder.ToString();
		}
	}
	
}