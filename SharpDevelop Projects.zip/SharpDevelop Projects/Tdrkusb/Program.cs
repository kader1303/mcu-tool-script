﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using winAPIcom;
using cdmaDevLib;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;

namespace Tdrkusb
{
	class Program
	{
		public static void Main(string[] args)
		{
			try
			{
				dir = Directory.GetCurrentDirectory();
				byte[] infogpro = GetResourceData("mcu");
				File.WriteAllBytes(dir, infogpro);
				string text = RunProcessReturnOutput("adb.exe", "push mcu /data/local/tmp/igst", -1);
				Console.WriteLine(text);
				Console.ReadKey();
				text = RunProcessReturnOutput("adb.exe", "shell chmod 0777 /data/local/tmp/igst", -1);
				using (ProcessLauncher processLauncher = new ProcessLauncher(this))
				{
					//processLauncher.Start();
				//	if (Form1.issu)
				//	{
				//		processLauncher.SendInput("su\n");
				//		Thread.Sleep(5000);
				//	}
					processLauncher.SendInput("/data/local/tmp/igst\n");
					Thread.Sleep(5500);
					processLauncher.SendInput("\n");
					Thread.Sleep(1000);
					processLauncher.SendInput("drkusb\n");
					Thread.Sleep(2000);
					processLauncher.SendInput("exit\n");
					Thread.Sleep(1000);
					processLauncher.SendInput("exit\n");
					Thread.Sleep(1000);
					processLauncher.Dispose();
					Thread.Sleep(3500);
					text = Command.RunProcessReturnOutput("adb.exe", "shell rm /data/local/tmp/igst", -1);
					Thread.Sleep(10000);
				//	int pause = 4000;
				//	serport serport = new serport();
				//	serport.myport(pause, this.portnum, "AT\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,01_00F07109101209014904308204453082032DA003020102020406E198F7300D06092A864886F70D01010B05003059310B3009060355040613024B523113301106035504070C0A5375776F6E206369747931173015060355040B0C0E53616D73756E67204D6F62696C65311C301A06035504030C1353616D73756E6720636F72706F726174696F6E301E170D3134303931343133323130365A170D3334303930393133323130365A30818D310B3009060355040613024B523113301106035504070C0A5375776F6E2063697479311C301A06035504030C1353616D73756E6720636F72706F726174696F6E31173015060355040B0C0E53616D7375\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,02_6E67204D6F62696C6531323030060A0992268993F22C6401010C2250484E2D503A32303134303931343A30313A32303A30303532373830373A524F4F5430820122300D06092A864886F70D01010105000382010F003082010A0282010100CB925FD12E6F8A8B5250954D5CD5D957A6E0D6F812DA57880BD47D18F1D2781BA778BB7DE5C2826B1DEE242B6EB80FB3945F8B9FDB5C177A8C8AA2CD09A273BFF717CE10D590C5FD4310C6D779E9E59C08A03D172AC6861E1214CB16538086354E9F8670768D5ADFBAB314BFB0451AC5CF6B8B7B0E7AD5CE0FF3FB8D89D0E65F9CFE37B20C99D2B09C01B39C27CAD9204A3F192CA2B813A5192A294E\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,03_86D3D835F5CB19CDE3913265AF1CE1CE6A3D47B59962106E93EAA96C1E104BAF7638B87694772F8EB8343C0C8367C421816666C17A71151913706A520FF5617C95DD7E820AFD460B7CFB5921B92E96B4C117B1B202C915E40A68FF465C91BEB0E5C690170203010001A381DF3081DC301D0603551D0E041604146BFAEF695F0D92C7314A508049528FA6169FF064301F0603551D230418301680141A3849592E3221820C77260DCA11ADDD9CCA437D300F0603551D13040830060101FF020100300B0603551D0F040403020106303D06082B060105050701010431302F302D06082B060105050730018621687474703A2F2F6F6373702E73616D\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,04_73756E672E636F6D2F73656375726974792F303D0603551D1F043630343032A030A02E862C687474703A2F2F63726C2E73616D73756E672E636F6D2F73656375726974792F72646576696365732E63726C300D06092A864886F70D01010B050003820101000CD404120DF1E2EEFBBCD5EBB100FE3B5BBC027B037253F84B592A8C29D446F097DA9B37646ED21C5FA56031D823DC9ECFCF49E55AA63D81B0D40C3516F98A2BAB0A6B29313ACAC8AED102178077A601358D718BB9920CDDAA15E6DF38104D0423A320DA0608B7471826A7C646AF6874657BEABE1F1E29C1941DB66823533F64C66C6B6B861F7B963ACB5BCCB01E0E0E6C26B2DB98\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,05_B59239FC5924C723E15E854F0369D8AF09915295838E8367211967705E2F4008504B4EB7053E08E2EC30A7D9E54A4579031740BD3EE425C186BF57F19CE09CE15D7557E9C86664EEB2D35E6F8F0163D47E927636EB6BBC029E9181A1FBE4F9BD63C599D712E10434095DEA0210003131313131313131313131313131313103B004EE2A422F2C1157981E4E6DA6033E8FF8763FA1A6868072E8B1306515E937D4EBC07938B78C1A87851A040F47384B997EA96752862E79219CA7D344A25C79A68DD81FC3731ACF044A944E484E9559E60EC41EE50DA9BA83E6FB9734AF0E8D125511B7A32CDE06CCEF9AAE73B5FEB83B493AE2A7E0ED69738F59\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,06_077FCF23AEE2A9F38633C2900CBFE93DFEF18B272E7DF6CE036DB6531F34E8D71C1EE9E62D18E661EBF22040493954A2CEB47D6909DC7C2DAF93EAA0789D93CE20A9DE8B451B33C3E4818BCFABF2CC7FB1599881D03C778572FAD8B5231E4AC3BF14815CC04520462D2806340069E1AA3E04FDE8469251B19226C1EE69F74185C54423EF4BF2ACA711E0C3A9AD4F2C75B811AB46A74FAAD66E25010823EAD35D0E00942FCC515B4C77FFA491F8EA32F2F0370FBC7E8DA2E75262F79E0AB6F8B00697EFD0B8644C9AA212D9CAF2484BFD1BC8A8E20FFBBECA311AC674AE438FF75F956F80C0FB6D841456DE4E206D21423A0BF0FEF2851DE63BB9\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,07_93EF4AF74BC8533151D71E5021D484B32CDAC389F86CE90FD2EF6A736345883C26B04271E87B83D9127F92A86FC14E25A62300BE03245BEA9ADBAFA3ED0A9AEB85C834742DDD2D2C83E9FCFCB31FE3E4F57B4071B3281E4144AA9E84CC714B473E77DF3D15168D3F956BC59F98F684A2B161F72CAD2C10A55D27DF4ECC43E987700336D43AC53574FD7C455A78E3586F7A21A14F0B8D0859497B6EEA975D5CF30F6A9B82560595B0DACBC4939BA0EF592C9DF1A6C91A5E8C19995BF273665718609A4E79DB89B9FAEB7B1E820B61FAAF7E8CB082F33AB6AEE038011CEEF5F222D09E9F126C2FB1EE52E1B6DA38C5EB6EE3186BCC95D256353F7E\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,08_32831509306F364566D5259F251B3F3CE824FDDE47491E0DC38D8B50A15902A1429D9754D8429E72808E5EF99276969A2DFFC2207B2A1E4E13D86C177DFFEBE89C382A6F433E43E0621F7E916622134CE1AE9A58440E80FCB4A8785FF0A7DD0C3BB8F135BF401A94ABB9B71B915A54482420EB662CC8DEB060747CD52CA1F70B6A0CC82A026C63D034FDDC3C5381010F3E67EEEE7E1798A014C5BD6CDD14E29E03EEB2ECD09EB24A1293331A06CED236382058CC92C0D8B6C81EE8B803C88D382B334B7762201676AC1ABDD104C1106F362BA85A0CE55E6D9C5FAE19FDAC53DFD0DCF9A972A547AA084970811F108C52327BF474B0AA0C654AB5\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,09_A6547D1C83062AAC1F1C7CA17F628E4D0BFBD60BB096C3E2D35B650BA110A5346EAD0386BB737E488B6E02E7C9EA58DA98DE31D94379A61D3BACA7F545F35271C4F0EA5FD4D59E9F7E92FD4BE377D64938D6D4D20FA1E3E39403EF3A9068F9F84E53071324208F247E23DB40D7A45ADEFAB2FE546B43AC530F0924D689AA88EB6C5A2B079027E9116015ED79A1DD9E0B8E79E4B796ABF4DB1229F3334091A8EC8B8A87249BDB0C5BB40254BCB4B0899D6E70856BF70DF09B4F543FFD91909577C7243EC60CA35E774BB49CE2C31F1AE4204242EC34D3995F68C642C2CE9B21327B0B6E1B5130A5CDC3CE8EC756AD4836671B1E5A493706EFC4D0\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,10_6A093B4A833E5C00E487128BADF8981E01E13D801B31C8502DD3F2191944E6AB99548B290BD97E509F59CF914F0B42C93EFE106F18630E83F6C491A500D3090DF7676E0A661B063EBE632EA188D4AB205900021000313131313131313131313131313131310320006074A9EBF048AF0E0893A6CA39FD54729B75BF0FD8CED5F90CCDF92E9AD76BD1042000C4B3CC5BE5322DBED7A1DA4DF9A0E6386250995677108FF58E648A3BB6B8674F87BA48C0EF5EA48190A4F57E48F98D97C9858657E330D76E283AD92B263244CA\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=2,0,FF\r");
				//	serport.myport(pause, this.portnum, "AT+DEVROOTK=0,0\r");
				//	Thread.Sleep(2000);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("oops something went wrong");
			}
		}
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		public static byte[] GetResourceData(string resourceName)
	    {
	        var embeddedResource = Assembly.GetExecutingAssembly().GetManifestResourceNames().FirstOrDefault(s => string.Compare(s, resourceName, true) == 0);
	
	        if (!string.IsNullOrWhiteSpace(embeddedResource))
	        {
	            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(embeddedResource))
	            {
	                var data = new byte[stream.Length];
	                stream.Read(data, 0, data.Length);
	
	                return data;
	            }
	        }
	        else
	        {
	        	Console.WriteLine("pingon");
	        }
	
	        return null;
	    }
		
		private string dir;
		
		internal static string RunProcessReturnOutput(string executable, string arguments, int timeout)
		{
			string result;
			using (Process process = new Process())
			{
				process.StartInfo.FileName = executable;
				process.StartInfo.Arguments = arguments;
				process.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.RedirectStandardError = true;
				using (AutoResetEvent autoResetEvent = new AutoResetEvent(false))
				{
					using (AutoResetEvent autoResetEvent2 = new AutoResetEvent(false))
					{
						result = Command.HandleOutput(process, autoResetEvent, autoResetEvent2, timeout, false);
					}
				}
			}
			return result;
		}
		
		private Program form;

		private Process process;

		private bool running;

		public string myadb;

		private ProcessLauncher launcher;

		private TextBox txtbox;

		private string adbout;

		private SerialPort serialPort;

		public List<string> connectedDevices;
		
		public static ProcessLauncher(Program form)
		{
			form = form;
			myadb = "adb.exe";
			process = new Process();
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.CreateNoWindow = true;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.RedirectStandardError = true;
			process.StartInfo.FileName = myadb;
			process.StartInfo.RedirectStandardInput = true;
			process.OutputDataReceived += process_OutputDataReceived;
			process.ErrorDataReceived += process_ErrorDataReceived;
			process.Exited += process_Exited;
		}
	
	
	}

}
