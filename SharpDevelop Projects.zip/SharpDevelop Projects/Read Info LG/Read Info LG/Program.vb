﻿'
' Created by SharpDevelop.
' User: Mundo Celular
' Date: 16/03/2020
' Time: 10:38-
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.IO
Imports System.IO.Ports
Imports System.Net
Imports System.Text
Imports System.Security.Cryptography

Module Program
	Sub Main()
		Console.WriteLine("Enter Port")
		serialPort = new SerialPort()
		Dim port As String = Console.ReadLine()
		serialPort.PortName = port
		serialPort.BaudRate = 9600
		serialPort.Parity = Parity.None
		serialPort.DataBits = 8
		serialPort.StopBits = StopBits.One
		serialPort.RtsEnable = true
		serialPort.DtrEnable = true
		serialPort.WriteBufferSize = 102400
		PserialPortort.DataReceived += ModuleTool.DataReceivedHandler
		serialPort.Open()
		if (serialPort.IsOpen) Then
			serialPort.BaseStream.Flush()
			byte[] array = new byte[]
			{
				239,
				160,	
				28,
				192,
				126
			}
			serialPort.Write(array, 0, array.Length)
			Thread.Sleep(3000)
			serialPort.BaseStream.Flush()
			serialPort.Close()
						
		Console.Write("Press any key to continue . . . ")
		Console.ReadKey(True)
		
	End Sub
End Module
