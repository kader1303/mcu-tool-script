﻿/*
 * Created by SharpDevelop.
 * User: HOME
 * Date: 3/19/2020
 * Time: 5:22 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;
using QC.QMSLPhone;

namespace TrestQCNLG
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
				bool ret = EnableDiag();
				Thread.Sleep(1000);
				if (ret != false)
				{
					Console.WriteLine("Reconecting LGE AndroidNet USB Serial Port...");
					SerialPort serialPort = new SerialPort();
					string text = DetectSerialPort("LGE Mobile");
					string text2 = DetectSerialPort("LGE AndroidNet USB Serial Port");
					if (string.IsNullOrEmpty(text) && string.IsNullOrEmpty(text2))
					{
						Console.WriteLine("No Port!");
					}
					else
					{
						int num = 0;
						int num2 = -1;
						string text3 = Regex.Split(text + text2, " ")[0].Trim();
						Console.WriteLine("[" + text3 + "]");
						try
						{
							phone.SetLibraryMode(LibraryModeEnum.QPhoneMS);
							phone.ConnectToServer(Convert.ToInt32(text3.Replace("COM", string.Empty)));
							if (!VerifyPhoneConnect(20, 1000))
							{
								Console.WriteLine("Fallo de conexion!");
							}
							Console.WriteLine("Authorizing NV access...");
							SPC = Console.ReadLine();
							phone.SendSPC(Encoding.ASCII.GetBytes(SPC));
							Console.WriteLine("OK!");
							Thread.Sleep(1000);
							Console.WriteLine("Writing...");
							string filein = Console.ReadLine();
							phone.LoadNVsFromQCN(filein, ref num, out num2);
							int num3 = 10;
							bool flag = false;
							while (!flag && num3 > 0)
							{
								num3--;
								try
								{
									phone.NV_WriteNVsToMobile(ref num2);
									flag = true;
								}
								catch (Exception ex)
								{
									Console.WriteLine(ex.Message);
								}
							}
							if (!flag)
							{
								Console.WriteLine("Fail Writing!");
							}
							else
							{
								Console.WriteLine("Syncronizing EFS...");
								phone.EFS_SyncWithWait(10000);
								Console.WriteLine("OK");
							}
						}
						catch
						{
							Console.WriteLine("FAIL!");
						}
						finally
						{
							phone.DisconnectServer();
						}
					}
				}
				else
				{
					Console.WriteLine("Fail DIAG!");
				}
				
			}
			else
			{
				Console.WriteLine("Wrong Auth!");
			}
			Console.WriteLine("Done!");
		}
		
		private static void UpdateLog(object sender, string information)
		{
			string text = "<NV_Process_Progress:";
			int num = information.LastIndexOf(text);
			if (num > 0)
			{
				string text2 = information.Substring(num + text.Length);
				text2 = text2.Substring(0, text2.IndexOf("%>"));
				Console.WriteLine(text2);
			}
		}
		
		private static Phone phone = new Phone();
		
		private static bool VerifyPhoneConnect(int tries, int sleepEachTryMilliSec)
		{
			bool flag = phone.IsPhoneConnected();
			while (!flag && tries > 0)
			{
				Thread.Sleep(sleepEachTryMilliSec);
				tries--;
				flag = phone.IsPhoneConnected();
			}
			return flag;
		}
		
		internal static string SPC { get; set; }
		
		internal static string FRPDONE { get; set; }
		
		private static string DetectSerialPort(string stringFindName)
		{
			string result = null;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				IEnumerable<string> portNames = SerialPort.GetPortNames();
				List<ManagementBaseObject> inner = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				foreach (string text in (from n in portNames
				join p in inner on n equals p["DeviceID"].ToString()
				select n + " - " + p["Caption"]).ToList<string>())
				{
					if (text.Contains(stringFindName))
					{
						result = text;
					}
				}
			}
			using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
			{
				IEnumerable<string> portNames2 = SerialPort.GetPortNames();
				IEnumerable<string> portWin10 = from p in managementObjectSearcher2.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>()
				select p["Caption"].ToString();
				portList = (from n in portNames2
				select n + " - " + portWin10.FirstOrDefault((string s) => s.Contains(n))).ToList<string>();
				foreach (string text2 in portList)
				{
					if (text2.Contains(stringFindName))
					{
						result = text2;
					}
				}
			}
			return result;
		}
		
		private static List<string> portList;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);

	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		internal static bool EnableDiag()
		{
			Console.WriteLine("Searching LGE AndroidNet USB Serial Port...");
			SerialPort serialPort = new SerialPort();
			string text = DetectSerialPort("LGE Mobile");
			string text2 = DetectSerialPort("LGE AndroidNet USB Serial Port");
			if (!string.IsNullOrEmpty(text) || !string.IsNullOrEmpty(text2))
			{
				string portName = Regex.Split(text + text2, " ")[0].Trim();
				Console.WriteLine("[" + portName + "]");
				try
				{
					serialPort.PortName = portName;
					serialPort.BaudRate = 9600;
					serialPort.Parity = Parity.None;
					serialPort.DataBits = 8;
					serialPort.StopBits = StopBits.One;
					serialPort.RtsEnable = true;
					serialPort.DtrEnable = true;
					serialPort.DataReceived += DataReceivedHandlerDIAG;
					int millisecondsTimeout = 500;
					serialPort.Open();
					if (!serialPort.IsOpen)
					{
						Console.WriteLine("fail opening Port!");
						return false;
					}
					byte[] array = new byte[]
					{
						0,
						120,
						240,
						126
					};
					FRPDONE = "Not";
					serialPort.BaseStream.Flush();
					serialPort.Write(array, 0, array.Length);
					Thread.Sleep(millisecondsTimeout);
					serialPort.BaseStream.Flush();
					serialPort.BaseStream.Flush();
					serialPort.Write(array, 0, array.Length);
					Thread.Sleep(millisecondsTimeout);
					serialPort.BaseStream.Flush();
					if (!(FRPDONE != "OK"))
					{
						Console.WriteLine("DIAG Active!");
						serialPort.Close();
						return true;
					}
					Console.WriteLine("Trying to enable Diagnostics ports..");
					serialPort.BaseStream.Flush();
					byte[] array2 = new byte[]
					{
						250,
						195,
						0,
						0,
						165,
						178,
						126
					};
					serialPort.Write(array2, 0, array2.Length);
					Thread.Sleep(1000);
					serialPort.BaseStream.Flush();
					serialPort.Write(array, 0, array.Length);
					Thread.Sleep(1000);
					serialPort.BaseStream.Flush();
					if (FRPDONE != "OK")
					{
						Console.WriteLine("Fail Activating Port!");
						serialPort.Close();
						return false;
					}
					Console.WriteLine("OK!");
					serialPort.Close();
					return true;
				}
				catch (Exception)
				{
					serialPort.Close();
					Console.WriteLine("Exception!");
					return false;
				}
			}
			Console.WriteLine("No Port!");
			return false;
		}
		
		public static void DataReceivedHandlerDIAG(object sender, SerialDataReceivedEventArgs e)
		{
			SerialPort serialPort = (SerialPort)sender;
			int bytesToRead = serialPort.BytesToRead;
			byte[] array = new byte[bytesToRead];
			if (serialPort.BytesToRead > 1)
			{
				serialPort.Read(array, 0, bytesToRead);
			}
			string text = BitConverter.ToString(array).Replace("-", string.Empty);
			if (text != null && text.Trim() != string.Empty)
			{
				FRPDONE = "OK";
			}
		}
		
	}
}