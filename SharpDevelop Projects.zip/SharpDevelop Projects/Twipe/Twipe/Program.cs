﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using winAPIcom;
using cdmaDevLib;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;

namespace Twipe
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
				SerialPort serialPort = new SerialPort();
				string text = DetectSerialPort("LGE Mobile");
				string text2 = DetectSerialPort("LGE AndroidNet USB Serial Port");
				if (!string.IsNullOrEmpty(text) || !string.IsNullOrEmpty(text2))
				{
					string portName = Regex.Split(text + text2, " ")[0].Trim();
					try
					{
						Console.WriteLine("[" + portName + "]");
						Thread.Sleep(1000);
						Console.WriteLine("Iniciando Proceso. . .");
						cdmaTerm.Connect(portName);
						Console.WriteLine(cdmaTerm.thePhone.LogData);
						cdmaTerm.SendTerminalCommand("00", true);
						cdmaTerm.SendTerminalCommand("00", true);
						cdmaTerm.SendTerminalCommand("00", true);
						cdmaTerm.SendTerminalCommand("00", true);
						cdmaTerm.SendTerminalCommand("00", true);
						cdmaTerm.SendTerminalCommand("7c00", true);
						cdmaTerm.SendTerminalCommand("262602", true);
						cdmaTerm.SendTerminalCommand("26bf01", true);
						cdmaTerm.SendTerminalCommand("26520000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000", true);
						cdmaTerm.SendTerminalCommand("11170006", true);
						cdmaTerm.SendTerminalCommand("4bfc0400", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("7c", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303000", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000100030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000200030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000300030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000400030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000500030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000600030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000700030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000800030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000900030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000a00030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000b00030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000c00030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000d00030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000e00030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331000f00030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331001000030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1331001100030000002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303100", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303200", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303300", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303400", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303500", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303600", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303700", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303800", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338303900", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313000", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313100", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313200", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313300", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313400", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313500", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313600", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313700", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313800", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f333338313900", true);
						cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
						cdmaTerm.SendTerminalCommand("290100", true);
						cdmaTerm.SendTerminalCommand("290200", true);
						cdmaTerm.SendTerminalCommand("290100", true);
						cdmaTerm.SendTerminalCommand("290200", true);
						cdmaTerm.Disconnect();
						Console.WriteLine("Listo!");
							
					}
					catch (Exception)
					{
						cdmaTerm.Disconnect();
					}
				}
				else
				{
					Console.WriteLine("No Port!");
				}
			}
			else
			{
				Console.WriteLine("Wrong Auth");
			}
		}
		
		private static string portraw { get; set; }
		
		private static string DetectSerialPort(string stringFindName)
		{
			string result = null;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				IEnumerable<string> portNames = SerialPort.GetPortNames();
				List<ManagementBaseObject> inner = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				foreach (string text in (from n in portNames
				join p in inner on n equals p["DeviceID"].ToString()
				select n + " - " + p["Caption"]).ToList<string>())
				{
					if (text.Contains(stringFindName))
					{
						result = text;
					}
				}
			}
			using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
			{
				IEnumerable<string> portNames2 = SerialPort.GetPortNames();
				IEnumerable<string> portWin10 = from p in managementObjectSearcher2.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>()
				select p["Caption"].ToString();
				portList = (from n in portNames2
				select n + " - " + portWin10.FirstOrDefault((string s) => s.Contains(n))).ToList<string>();
				foreach (string text2 in portList)
				{
					if (text2.Contains(stringFindName))
					{
						result = text2;
					}
				}
			}
			return result;
		}
		
		private static List<string> portList;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
	}
}