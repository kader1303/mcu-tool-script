﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 19/04/2020
 * Time: 07:27-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace cert
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			AT = "6B54E9B7DA4C89BD5339AD2CCEB7B2DF970E4F39FC79D2948B74AE5B8E787B767EC31C51B0AC06BDAC8ADF4800CD1649A4CD6A4D1D3C3B5C9B8A1DB0EDB282AF49AF84C419E0646E2C1C0A9B4014DEA6B1EEF33207E0DD5A480A2F65EF8F2CBFBD70A62CF18C255A1AFDB2F7A4A351388ACF3034B9A268A6AC51C1D73B6BAAED81EFFDEE0B70CAEA842A3BB6092AE92B4FB08E9DE24FE5026EA69611077A2CDA80FF7214AF1654692A40F8EF5F14AB5DDA87F8433FEFE88B45A282B8AEDC95058D38C4AD61DBC743642FFB1ECC71FE843375A5859654AA620C381A175DDEC90518CB2627130F9858D2082E586921937F29F226025B4FF73AFE01FFE76D17FD366B5B7DBC2BC7F3ED4E7F3484828CCC5D9E7B579133EEDCBA683E4F7DC1667F3CB742B29B5206354AE35B7256391AAE61D8EB6ED94938780FDC0C68211C065167B4ABB873CB7131DBD936AFCE4EBBBE0036CCA0E2CA60469455864288033AE14516CA40735B0F289EA460682B628E33B84C65B9723F012144EC7DAEB6D9493C985A2E7D713722EA6F94D64D891DA1F486F0254E30744E48AB6FB5859F13DD1CFA5E0411AE0D74399678BCACB0259982CA50D86647D6F8898D73F9D4278E549EF478CBF25A5DD64773D4B717446F0285BCAA38776783F2D852C0A6847A93CCE419609C7E3EBBF1D570294ED162ABE47402A8D1F32D2F955B37A081984775048018BF15016DCEA187876448E5CE26DBA5B3788E2FBC26C8863EFFB24512EFAD056B716004BA22E30E4D7A2924BE1007C4B2610FA3DB74DB307B7045355BD7910D7752DCE7E83E040BC7CCEDA5D706074D500C17FD567C61554EC7D8C8B7EB6692198FE8449639524ED45E4DB2033130D6697F7772521B7F9CBB1544EC892225A18C776BD92A9CC1225F8631FD4BBC0E64D54353C0A585CF383865492B59701ED23033AFF1972A19FED56AC2AEDFF650C678718A261487D8BB7FE22EAA75668772C3BCF84198B1E67B9E90051556A7FCDBBC48AE81C66F37F22BD884079CDF668209871D2349A3ECDFB442535C522ACBF2C423D29B764599E9F2EC1A48C6AB6F8DB1B98FA7547FE68B17FEF8A5796EA7430D5DAA2AE796FEFEA10ABE97DAA8D1D923C693839F433229B718FBAAE9615B2302052C8EF2ADAFBA20386A245EDEA94A4DBABB5C250F57FD80DFF4EE1D2A22F565EDBD637D679BC1F87BE88D50E8CEE0385A947D6F12DA6F9866FBB18946F257908F83449A22D0376D3413EEE0FF7F34CEACBAAE17463C1D32D1983283B6648130705C37084490EE3D007F519949A82819E3A321CDFD75A914A3F5A2CFD0B303159FA488D3C84EF48DA1E096A0185B469934DE404C420F57EF892533DF8E2EE326662EAB234B473293FE23C08AF9E7115932323444E81B580306DDF54BB2070288B2B8747A5847B86CB27E2A53C13EA1EB8660FA640105FB8B";
			string text = ASCIITOHex(EncryptString(AT));
			byte[] bytes = Encoding.ASCII.GetBytes(string.Concat(new string[]
			{
				"username=",
				"13055876172",
				"&password=",
				"RaejLQfnlY",
				"&string=",
				text
			}));
			WebRequest webRequest = WebRequest.Create("http://kingunlock.net/kingapi/certcalc");
			webRequest.Method = "POST";
			webRequest.ContentType = "application/x-www-form-urlencoded";
			webRequest.ContentLength = (long)bytes.Length;
			using (Stream requestStream = webRequest.GetRequestStream())
			{
				requestStream.Write(bytes, 0, bytes.Length);
			}
			string result = null;
			using (WebResponse response = webRequest.GetResponse())
			{
				using (Stream responseStream = response.GetResponseStream())
				{
					using (StreamReader streamReader = new StreamReader(responseStream))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
			
			Console.Write(result);
		//	Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
		
		public static string ASCIITOHex(string ascii)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in Encoding.UTF8.GetBytes(ascii))
			{
				stringBuilder.Append(string.Format("{0:x2}", b));
			}
			return stringBuilder.ToString();
		}
		
		public static string EncryptString(string plainText)
		{
			string s = "KingToolsEncrypt";
			byte[] sourceArray = SHA256.Create().ComputeHash(Encoding.ASCII.GetBytes(s));
			byte[] iv = new byte[16];
			Aes aes = Aes.Create();
			aes.Mode = CipherMode.CBC;
			byte[] array = new byte[32];
			Array.Copy(sourceArray, 0, array, 0, 32);
			aes.Key = array;
			aes.IV = iv;
			MemoryStream memoryStream = new MemoryStream();
			ICryptoTransform transform = aes.CreateEncryptor();
			CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
			byte[] bytes = Encoding.ASCII.GetBytes(plainText);
			cryptoStream.Write(bytes, 0, bytes.Length);
			cryptoStream.FlushFinalBlock();
			byte[] array2 = memoryStream.ToArray();
			memoryStream.Close();
			cryptoStream.Close();
			return Convert.ToBase64String(array2, 0, array2.Length);
		}
		
		internal static string AT { get; set; }
	}
}