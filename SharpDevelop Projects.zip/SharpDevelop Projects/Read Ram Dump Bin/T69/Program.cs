﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 12/04/2020
 * Time: 07:18-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Management;
using System.Text.RegularExpressions;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;

namespace T69
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
		//	var pass = Console.ReadLine();
		//	if (pass == hash)
		//	{
				Console.WriteLine("Reading...");
				try
				{
					string name = Console.ReadLine();
					Thread.Sleep(1000);
					string path = string.Concat(new string[]
					{
						Directory.GetCurrentDirectory(),
						"\\",
						name
					});
						Console.WriteLine(path);
						string text = smethod_1(FileToByteArray(path));
						Console.WriteLine(text);
				}
				catch (Exception)
				{
					Console.WriteLine("Error!");
				}
		//	}
		//	else
		//	{
		//		Console.Write("Wrong Key!");
		//	}
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey();
		}
		
		static private List<string> list_0;
		
		internal static string IMEISIGN { get; set; }
		
		internal static string smethod_1(byte[] byte_0)
		{
			return new SoapHexBinary(byte_0).ToString();
		}
		
		public static byte[] FileToByteArray(string fileName)
		{
			byte[] result = null;
			using (FileStream fileStream = File.OpenRead(fileName))
			{
				using (BinaryReader binaryReader = new BinaryReader(fileStream))
				{
					result = binaryReader.ReadBytes((int)fileStream.Length);
				}
			}
			return result;
		}
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		public static void ReadIMEISIGN() //Esta es la que debe darnos IMEISIGN del .bin leido pero no devuelve nada en ningun caso, revisala a ver que te parece
		{
			string text = SerialCOM.smethod_1(FileToByteArray(ModuleParams.BinaryFile()));
			int length = text.Length;
			int num = length;
			for (int i = 1; i
		     <= num; i++)
			{
				try
					{
						if ((!text.Substring(length - i, 512).Contains("000000") & !text.Substring(length - i, 512).Contains("2E636F6D")) && (!text.Substring(length - i, 512).Contains("FFFFFF") & !text.Substring(length - i, 512).Contains("43657274")) && !text.Substring(length - i, 6).Contains("789C") && !text.Substring(length - i, 512).Contains("B3B7AC8D") && !text.Substring(length - i, 512).Contains("B3B68B33") && !text.Substring(length - i, 3).Contains("FFF") && !text.Substring(length - i, 3).Contains("000") && !text.Substring(length - i + 508, 3).Contains("FFF") && !text.Substring(length - i + 508, 3).Contains("000") && !text.Substring(length - i, 512).Contains("55C18D7A") && !text.Substring(length - i, 512).Contains("8A5C37E139") && !text.Substring(length - i - 3, 512).Contains(ModuleParams.PUBKEYSIGN_COUNT) && !text.Substring(length - i, 512).Contains("CA670BF83") && !text.Substring(length - i + 10, 522).Contains(text.Substring(length - i + 5, 5)) && text.Substring(length - i, 512).Split(new char[]
						{
							'0'
						}).Count<string>() < 100 && text.Substring(length - i, 512).Split(new char[]
						{
							Conversions.ToChar(text.Substring(length - i, 1))
						}).Count<string>() < 100 && text.Substring(length - i + 512, 512).Split(new char[]
						{
							'0'
						}).Count<string>() == 513 && ((text.Substring(length - i - 2, 2).Split(new char[]
						{
							'F'
						}).Count<string>() == 3 && text.Substring(length - i - 1, 1).Split(new char[]
						{
							'F'
						}).Count<string>() == 2 && text.Substring(length - i - 3, 3).Split(new char[]
						{
							'F'
						}).Count<string>() == 4) | text.Substring(length - i - 6, 6).Split(new char[]
						{
							'0'
						}).Count<string>() == 7) && (length - i) % 4 == 0 && !list_0.Contains(text.Substring(length - i, 512)))
						{
							list_0.Add(text.Substring(length - i, 512));
							ModuleParams.IMEISIGN = text.Substring(length - i, 512);
						}
					}
					catch (Exception)
					{
					}
			}
		}
	}
}