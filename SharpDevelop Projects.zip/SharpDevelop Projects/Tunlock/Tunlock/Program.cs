﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using winAPIcom;
using cdmaDevLib;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;

namespace Twipe
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
				Console.WriteLine("Iniciando Proceso. . .");
				string portName = Console.ReadLine();
				cdmaTerm.Connect(portName);
				Console.WriteLine(cdmaTerm.thePhone.LogData);
				cdmaTerm.SendTerminalCommand("41303030303030", true);
				cdmaTerm.SendTerminalCommand("290100", true);
				cdmaTerm.SendTerminalCommand("2000db", true);
				cdmaTerm.SendTerminalCommand("fc", true);
				cdmaTerm.SendTerminalCommand("850200", true);
				cdmaTerm.SendTerminalCommand("2626020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000d90a", true);
				cdmaTerm.SendTerminalCommand("4b130900ff017075626c696300", true);
				cdmaTerm.SendTerminalCommand("4b1313002f00", true);
				cdmaTerm.SendTerminalCommand("4b13250000002f7075626c69632f2e2e2f6e766d2f6e756d2f313030383000", true);
				cdmaTerm.SendTerminalCommand("4b1328000000000000002f6e766d2f6e756d2f313030383000", true);
				cdmaTerm.SendTerminalCommand("4b13300001002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000100050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000200050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000300050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000400050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000500050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000600050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000700050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000800050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000900050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000a00050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000b00050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000c00050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000d00050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000e00050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331000f00050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331001000050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331001100050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331001200050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331001300050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331001400050000002f00", true);
				cdmaTerm.SendTerminalCommand("4b1331001500050000002f00", true);
				cdmaTerm.SendTerminalCommand("290200", true);
				cdmaTerm.Disconnect();
				Console.WriteLine("Listo!");
			}
			else
			{
				Console.WriteLine("Wrong Auth");
			}
		}
		
		private static string portraw { get; set; }
		
		private static string DetectSerialPort(string stringFindName)
		{
			string result = null;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				IEnumerable<string> portNames = SerialPort.GetPortNames();
				List<ManagementBaseObject> inner = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				foreach (string text in (from n in portNames
				join p in inner on n equals p["DeviceID"].ToString()
				select n + " - " + p["Caption"]).ToList<string>())
				{
					if (text.Contains(stringFindName))
					{
						result = text;
					}
				}
			}
			using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
			{
				IEnumerable<string> portNames2 = SerialPort.GetPortNames();
				IEnumerable<string> portWin10 = from p in managementObjectSearcher2.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>()
				select p["Caption"].ToString();
				portList = (from n in portNames2
				select n + " - " + portWin10.FirstOrDefault((string s) => s.Contains(n))).ToList<string>();
				foreach (string text2 in portList)
				{
					if (text2.Contains(stringFindName))
					{
						result = text2;
					}
				}
			}
			return result;
		}
		
		private static List<string> portList;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
	}
}