﻿/*
 * Created by SharpDevelop.
 * User: HOME
 * Date: 3/19/2020
 * Time: 4:17 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Permissions;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;
using QC.QMSLPhone;

namespace TqcnSam
{
	class Program
	{
		public static void Main(string[] args)
		{	
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
				Console.WriteLine("Searching for SAMSUNG Diagnostic Port...");
				string text = DetectSerialPort("SAMSUNG Mobile USB Serial Port");
				if (string.IsNullOrEmpty(text))
				{
					Console.WriteLine("FAIL!");
				}
				else
				{
					Thread.Sleep(1000);
					int num = -1;
					string text2 = Regex.Split(text, " ")[0].Trim();
					Console.WriteLine("[" + text2 + "]");
					MODEL = Console.ReadLine();
					Console.WriteLine("Connecting...");
					IMEI = Console.ReadLine();
					phone.SetLibraryMode(LibraryModeEnum.QPhoneMS);
					phone.ConnectToServer(Convert.ToInt32(text2.Replace("COM", string.Empty)));
					phone.NV_SetTargetSupportMultiSIM(true);
					if (!VerifyPhoneConnect(20, 1000))
					{
						Console.WriteLine("FAIL CONNECTING!");
					}
					else
					{
						Console.WriteLine("Authorizing NV access...");
						SPC = Console.ReadLine();
						phone.SendSPC(Encoding.ASCII.GetBytes(SPC));
						phone.EnableQcnNvItemCallBacks();
						phone.OnNvEvent += UpdateLog;
						phone.BackupNVFromMobileToQCN(SecFile(), ref num);
						Console.WriteLine("Read Ok!");
					}
				}
			}
			else
			{
				Console.WriteLine("Wrong Auth!");
			}
			Console.WriteLine("Done!");
		}
		
		private static void UpdateLog(object sender, string information)
		{
			string text = "<NV_Process_Progress:";
			int num = information.LastIndexOf(text);
			if (num > 0)
			{
				string text2 = information.Substring(num + text.Length);
				text2 = text2.Substring(0, text2.IndexOf("%>"));
				Console.WriteLine(text2);
			}
		}
		
		private static Phone phone = new Phone();
		
		private static bool VerifyPhoneConnect(int tries, int sleepEachTryMilliSec)
		{
			bool flag = phone.IsPhoneConnected();
			while (!flag && tries > 0)
			{
				Thread.Sleep(sleepEachTryMilliSec);
				tries--;
				flag = phone.IsPhoneConnected();
			}
			return flag;
		}
		
		internal static string DetectSerialPort(string stringFindName)
		{
			string result = null;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				IEnumerable<string> portNames = SerialPort.GetPortNames();
				List<ManagementBaseObject> inner = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				foreach (string text in (from n in portNames
				join p in inner on n equals p["DeviceID"].ToString()
				select n + " - " + p["Caption"]).ToList<string>())
				{
					if (text.Contains(stringFindName))
					{
						result = text;
					}
				}
			}
			using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
			{
				IEnumerable<string> portNames2 = SerialPort.GetPortNames();
				IEnumerable<string> portWin10 = from p in managementObjectSearcher2.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>()
				select p["Caption"].ToString();
				portList = (from n in portNames2
				select n + " - " + portWin10.FirstOrDefault((string s) => s.Contains(n))).ToList<string>();
				foreach (string text2 in portList)
				{
					if (text2.Contains(stringFindName))
					{
						result = text2;
					}
				}
			}
			return result;
		}
		
		private static List<string> portList;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		internal static string MODEL { get; set; }
		
		internal static string IMEI { get; set; }
		
		internal static string SPC { get; set; }
		
		public static string SecFile()
		{
			return string.Concat(new object[]
			{
				Directory.GetCurrentDirectory(),
				"\\Backup\\",
				MODEL,
				"_",
				IMEI,
				".qcn"
			});
		}
	}
}