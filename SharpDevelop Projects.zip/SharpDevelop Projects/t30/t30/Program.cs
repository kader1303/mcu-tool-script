﻿/*
 * Created by SharpDevelop.
 * User: HOME
 * Date: 3/19/2020
 * Time: 2:30 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;

namespace t30
{
	class Program
	{
		public static void Main(string[] args)
		{
			SerialPort serialPort = new SerialPort();
			string text = DetectSerialPort("LGE Mobile");
			string text2 = DetectSerialPort("LGE AndroidNet USB Serial Port");
			if (!string.IsNullOrEmpty(text) || !string.IsNullOrEmpty(text2))
			{
				string portName = Regex.Split(text + text2, " ")[0].Trim();
				try
				{
					serialPort.PortName = portName;
					serialPort.BaudRate = 9600;
					serialPort.Parity = Parity.None;
					serialPort.DataBits = 8;
					serialPort.StopBits = StopBits.One;
					serialPort.RtsEnable = true;
					serialPort.DtrEnable = true;
					serialPort.WriteBufferSize = 102400;
					int millisecondsTimeout = 3000;
					serialPort.DataReceived += DataReceivedHandlerSPC;
					serialPort.Open();
					if (serialPort.IsOpen)
					{
						Console.WriteLine("Calculando SPC...");
						serialPort.BaseStream.Flush();
						byte[] array = new byte[]
						{
							17,
							23,
							0,
							8,
							28,
							166,
							126
						};
						serialPort.Write(array, 0, array.Length);
						Thread.Sleep(millisecondsTimeout);
						serialPort.BaseStream.Flush();
						serialPort.Close();
					}
					else
					{
						Console.WriteLine("Fail open port");
					}
				}
				catch (Exception)
				{
					serialPort.Close();
				}
			}
			else
			{
				Console.WriteLine("No Port!");
			}
			Console.WriteLine("Done!");
			Console.ReadKey();
		}
		
		public static void DataReceivedHandlerSPC(object sender, SerialDataReceivedEventArgs e)
		{
			SerialPort serialPort = (SerialPort)sender;
			int bytesToRead = serialPort.BytesToRead;
			byte[] array = new byte[bytesToRead];
			if (serialPort.BytesToRead > 1)
			{
				serialPort.Read(array, 0, bytesToRead);
			}
			string asciistring = ConversionUtils.GetASCIIString(BitConverter.ToString(array).Replace("-", string.Empty));
			if (asciistring != null && asciistring.Trim() != string.Empty && asciistring.Length > 6)
			{
				string text = asciistring.Substring(3, 6);
				Console.WriteLine("SPC Code: " + text);
			}
		}
		
		private static string DetectSerialPort(string stringFindName)
		{
			string result = null;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				IEnumerable<string> portNames = SerialPort.GetPortNames();
				List<ManagementBaseObject> inner = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				foreach (string text in (from n in portNames
				join p in inner on n equals p["DeviceID"].ToString()
				select n + " - " + p["Caption"]).ToList<string>())
				{
					if (text.Contains(stringFindName))
					{
						result = text;
					}
				}
			}
			using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
			{
				IEnumerable<string> portNames2 = SerialPort.GetPortNames();
				IEnumerable<string> portWin10 = from p in managementObjectSearcher2.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>()
				select p["Caption"].ToString();
				portList = (from n in portNames2
				select n + " - " + portWin10.FirstOrDefault((string s) => s.Contains(n))).ToList<string>();
				foreach (string text2 in portList)
				{
					if (text2.Contains(stringFindName))
					{
						result = text2;
					}
				}
			}
			return result;
		}
		
		private static List<string> portList;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
	}
	
	internal class ModuleEncrypt
	{
		public ModuleEncrypt()
		{
			this._key = LgLaf.KEY;
			this._kiloChallenge = LgLaf.KILOCHALL;
		}
		
		public static int CRC16CT(byte[] data)
		{
			int num = 65535;
			foreach (byte b in data)
			{
				num ^= (int)b;
				for (int j = 0; j < 8; j++)
				{
					if ((num & 1) == 0)
					{
						num >>= 1;
					}
					else
					{
						num = (num >> 1 ^ 33800);
					}
				}
			}
			return num ^ 65535;
		}
		
		private string _key;

		private string _kiloChallenge;

		private byte[] _header;
		
		public void SetHeader(int offset, byte[] val)
		{
			if (val.Length != 4)
			{
				throw new Exception(string.Format("Header field requires a DWORD, got {0} {0}", val.GetType(), val));
			}
			try
			{
				for (int i = 0; i < 4; i++)
				{
					this._header[offset + i] = val[i];
				}
			}
			catch (Exception arg)
			{
				Console.WriteLine("SetHeader - Error: {0}", arg);
			}
		}
		
		public byte[] MakeRequestMETR()
		{
			ModuleEncrypt moduleEncrypt = new ModuleEncrypt();
			string s = "KILO";
			byte[] source = moduleEncrypt.EncryptKiloChallenge();
			byte[] array = ConversionUtils.HexStringToBytes(string.Join("", (from c in source
			select c.ToString("X2")).ToArray<string>()).Substring(0, 32));
			string[] array2 = new string[]
			{
				"METR",
				"\0\0\0\0",
				"\u0002\0\0\0",
				"\0\0\0\0"
			};
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			this._header = new byte[32];
			this.SetHeader(0, bytes);
			for (int i = 0; i < array2.Length; i++)
			{
				byte[] bytes2 = Encoding.ASCII.GetBytes(array2[i]);
				this.SetHeader(4 * (i + 1), bytes2);
			}
			byte[] bytes3 = BitConverter.GetBytes(array.Length);
			this.SetHeader(20, bytes3);
			this.SetHeader(28, this.InvertDWORD(bytes));
			this.AddHeader(array);
			byte[] bytes4 = BitConverter.GetBytes(this.CRC16(this._header));
			this.SetHeader(24, bytes4);
			return this._header;
		}
		
		public byte[] MakeRequestMETRCLOSE()
		{
			ModuleEncrypt moduleEncrypt = new ModuleEncrypt();
			string s = "KILO";
			byte[] source = moduleEncrypt.EncryptKiloChallenge();
			byte[] array = ConversionUtils.HexStringToBytes(string.Join("", (from c in source
			select c.ToString("X2")).ToArray<string>()).Substring(0, 32));
			string[] array2 = new string[]
			{
				"METR",
				"\0\0\0\0",
				"\u0004\0\0\0",
				"\0\0\0\0"
			};
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			this._header = new byte[32];
			this.SetHeader(0, bytes);
			for (int i = 0; i < array2.Length; i++)
			{
				byte[] bytes2 = Encoding.ASCII.GetBytes(array2[i]);
				this.SetHeader(4 * (i + 1), bytes2);
			}
			byte[] bytes3 = BitConverter.GetBytes(array.Length);
			this.SetHeader(20, bytes3);
			this.SetHeader(28, this.InvertDWORD(bytes));
			this.AddHeader(array);
			byte[] bytes4 = BitConverter.GetBytes(this.CRC16(this._header));
			this.SetHeader(24, bytes4);
			return this._header;
		}
		
		public void AddHeader(byte[] b)
		{
			byte[] array = new byte[this._header.Length + b.Length];
			for (int i = 0; i < this._header.Length; i++)
			{
				array[i] = this._header[i];
			}
			for (int j = 0; j < b.Length; j++)
			{
				array[this._header.Length + j] = b[j];
			}
			this._header = array;
		}
		
		public int CRC16(byte[] data)
		{
			int num = 65535;
			foreach (byte b in data)
			{
				num ^= (int)b;
				for (int j = 0; j < 8; j++)
				{
					if ((num & 1) == 0)
					{
						num >>= 1;
					}
					else
					{
						num = (num >> 1 ^ 33800);
					}
				}
			}
			return num ^ 65535;
		}
		
		public byte[] InvertDWORD(byte[] b)
		{
			for (int i = 0; i < b.Length; i++)
			{
				int num = i;
				b[num] ^= byte.MaxValue;
			}
			return b;
		}
		
		public byte[] EncryptKiloChallenge()
		{
			byte[] array = new byte[16];
			for (int i = 0; i < 16; i++)
			{
				array[i] = (byte)i;
			}
			byte[] key = this.KeyTransform(LgLaf.KEY);
			byte[] key2 = this.KeyXOR(key, this.CovertStringHexToByte(LgLaf.KILOCHALL));
			byte[] result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = key2;
				result = this.AESEncrypt(Encoding.ASCII.GetString(array), aes.Key, aes.IV);
			}
			return result;
		}
		
		private byte[] CovertStringHexToByte(string str)
		{
			return (from x in Enumerable.Range(0, str.Length)
			where x % 2 == 0
			select Convert.ToByte(str.Substring(x, 2), 16)).ToArray<byte>();
		}
		
		public byte[] KeyTransform(string oldKey)
		{
			byte[] bytes = Encoding.ASCII.GetBytes(oldKey);
			byte[] array = new byte[bytes.Length];
			for (int i = 32; i > 0; i--)
			{
				byte b = bytes[i - 1];
				array[bytes.Length - i] = (byte)((int)b - i % 12);
			}
			return array;
		}
		
		public byte[] KeyXOR(byte[] key, byte[] kiloChallenge)
		{
			byte[] array = new byte[32];
			for (int i = 0; i < 32; i += 4)
			{
				array[i] = (byte) (key[i] ^ kiloChallenge[3]);
				array[i + 1] = (byte) (key[i + 1] ^ kiloChallenge[2]);
				array[i + 2] = (byte) (key[i + 2] ^ kiloChallenge[1]);
				array[i + 3] = (byte) (key[i + 3] ^ kiloChallenge[0]);
			}
			return array;
		}
		
		public byte[] AESEncrypt(string plainText, byte[] Key, byte[] IV)
		{
			if (plainText == null || plainText.Length <= 0)
			{
				throw new ArgumentNullException("plainText");
			}
			if (Key == null || Key.Length == 0)
			{
				throw new ArgumentNullException("Key");
			}
			if (IV == null || IV.Length == 0)
			{
				throw new ArgumentNullException("IV");
			}
			byte[] result;
			using (Aes aes = Aes.Create())
			{
				aes.Key = Key;
				aes.IV = IV;
				aes.Mode = CipherMode.ECB;
				ICryptoTransform transform = aes.CreateEncryptor(aes.Key, aes.IV);
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write))
					{
						using (StreamWriter streamWriter = new StreamWriter(cryptoStream))
						{
							streamWriter.Write(plainText);
						}
						result = memoryStream.ToArray();
					}
				}
			}
			return result;
		}
	}
	
	public class ConversionUtils
	{
		public static byte[] HexStringToBytes(string strInput)
		{
			checked
			{
				byte[] result;
				try
				{
					int num = 0;
					int num2 = 0;
					byte[] array = new byte[(int)Math.Round(unchecked((double)strInput.Length / 2.0 - 1.0)) + 1];
					while (strInput.Length > num + 1)
					{
						long value = Convert.ToInt64(strInput.Substring(num, 2), 16);
						array[num2] = Convert.ToByte(value);
						num += 2;
						unchecked
						{
							num2++;
						}
					}
					result = array;
				}
				catch (Exception)
				{
					Interaction.MsgBox("Hex String To Byte Array Conversion Error!", MsgBoxStyle.Critical, null);
					result = null;
				}
				return result;
			}
		}
		
		public static string GetASCIIString(string hexString)
		{
			string result;
			try
			{
				string text = "";
				int num = checked(hexString.Length - 1);
				for (int i = 0; i <= num; i++)
				{
					if (Operators.CompareString(hexString.Substring(i, 2), "00", false) != 0)
					{
						text += hexString.Substring(i, 2);
						i++;
					}
					else
					{
						i++;
					}
				}
				string text2 = "";
				while (text.Length > 0)
				{
					text2 += Convert.ToChar(Convert.ToUInt64(text.Substring(0, 2), 16)).ToString();
					text = text.Substring(2, checked(text.Length - 2));
				}
				result = text2;
			}
			catch (Exception)
			{
				result = "-1";
			}
			return result;
		}
	}
	
	internal class LgLaf
	{
		internal static string FD_NUM { get; set; }
		
		internal static string OPENSDGOFF { get; set; }

		internal static string FRPDONE { get; set; }

		internal static string ERASE { get; set; }
		
		internal static string READ { get; set; }
		
		internal static string KILOCHALL { get; set; }

		internal static string WRITE { get; set; }
		
		internal static string PORT { get; set; }

		internal static byte[] CTRLRSET = ConversionUtils.HexStringToBytes("4354524c5253455400000000000000000000000000000000c7eb0000bcabadb3");

		internal static byte[] HELLO = ConversionUtils.HexStringToBytes("48454c4f01000001000000000000000001000000000000004c3f0000b7bab3b0");

		internal static byte[] KILOCENT = ConversionUtils.HexStringToBytes("4b494c4f43454e5400000000000000000000000000000000e37b0000b4b6b3b0");

		internal static byte[] OPENSDF = ConversionUtils.HexStringToBytes("4f50454e0000000000000000000000000000000014010000af2a0000b0afbab12f6465762f626c6f636b2f736466000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000200b68100000000b6010000000000000000");

		internal static byte[] OPENSDB = ConversionUtils.HexStringToBytes("4f50454e000000000000000000000000000000001401000094d60000b0afbab12f6465762f626c6f636b2f736462000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000200b68100000000b6010000000000000000");

		internal static byte[] OPENSDE = ConversionUtils.HexStringToBytes("4f50454e0000000000000000000000000000000014010000b8290000b0afbab12f6465762f626c6f636b2f736465000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000200b68100000000b6010000000000000000");

		internal static byte[] INFOPROP = ConversionUtils.HexStringToBytes("494e464f4750524f000000000000000000000000080b00003dbc0000b6b1b9b0080b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");

		internal static byte[] OPENSDG = ConversionUtils.HexStringToBytes("4f50454e0000000000000000000000000000000014010000add30000b0afbab12f6465762f626c6f636b2f736467000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000200b68100000000b6010000000000000000");

		internal static byte[] OPENSDA = ConversionUtils.HexStringToBytes("4f50454e000000000000000000000000000000001401000083d50000b0afbab12f6465762f626c6f636b2f736461000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002000200b68100000000b6010000000000000000");

		internal static string KEY = "qndiakxxuiemdklseqid~a~niq,zjuxl";
	}
	
}