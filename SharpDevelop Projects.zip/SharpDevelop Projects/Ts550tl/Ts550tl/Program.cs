﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 19/03/2020
 * Time: 07:45-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 
using System;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;

namespace Ts550tl
{
	class Program
	{
		public static void Main(string[] args)
		{
			try
			{
				Console.WriteLine("Iniciando procedimiento...");
				var portnum = Console.ReadLine();
				serialPort = new SerialPort();
				serialPort.PortName = "\\\\.\\" + portnum;
				serialPort.BaudRate = 115200;
				serialPort.Parity = Parity.None;
				serialPort.DataBits = 8;
				serialPort.StopBits = StopBits.One;
				serialPort.Handshake = Handshake.RequestToSend;
				serialPort.DtrEnable = true;
				serialPort.RtsEnable = true;
				serialPort.NewLine = Environment.NewLine;
				Thread.Sleep(1000);
				serialPort.Open();
				serialPort.DataReceived += SerialPort_ReceivedEvent2;
				if (serialPort.IsOpen)
				{ 
					Console.WriteLine("Desbloqueando...");
					Thread.Sleep(1000);
					serialPort.WriteLine("AT+NVVALUEGETINFO=\"CAL.Common.LOCK_LEVEL\"\r");
					Thread.Sleep(3000);
					s550tlunlock_p2();
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error 1!");
			}
		}
		
		private static SerialPort serialPort;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		private static string msladd2;
		
		private static string msladd;
		
		private static string prevadd;
		
		private static string cmladd;
		
		private static string cmladd2;
		
		private static string cmkadd2;

		private static string cmkadd;
		
		private static string cmkprevadd;

		private static string cmkprevadd2;
		
		private static string cmkprevadd3;
		
		private static string cmkprevadd4;

		private static string cmkprevadd5;
		
		private static bool comisread;
		
		private static void SerialPort_ReceivedEvent2(object sender, SerialDataReceivedEventArgs e)
		{
			try
			{
				string text = ((SerialPort)sender).ReadExisting();
				if (text.Contains("CAL.Common.MSL_ADDR_ENC :"))
				{
					using (StringReader stringReader = new StringReader(text))
					{
						int num = 0;
						string text2;
						while ((text2 = stringReader.ReadLine()) != null)
						{
							num++;
							if (text2.Contains("CAL.Common.MSL_ADDR_ENC :"))
							{
								string[] array = Regex.Split(Regex.Split(text2, ":")[1], ",");
								msladd2 = array[0];
							}
						}
						msladd = msladd2;
						int num2 = Convert.ToInt32(msladd);
						prevadd = Convert.ToString(num2 - 1);
					}
				}
				if (text.Contains("CAL.Common.LOCK_LEVEL :"))
				{
					using (StringReader stringReader2 = new StringReader(text))
					{
						int num3 = 0;
						string text3;
						while ((text3 = stringReader2.ReadLine()) != null)
						{
							num3++;
							if (text3.Contains("CAL.Common.LOCK_LEVEL :"))
							{
								string[] array2 = Regex.Split(Regex.Split(text3, ":")[1], ",");
								cmladd2 = array2[0];
							}
						}
						cmladd = cmladd2;
					}
				}
				if (text.Contains("CAL.Common.MASTER_KEY_ENC :"))
				{
					using (StringReader stringReader3 = new StringReader(text))
					{
						int num4 = 0;
						string text4;
						while ((text4 = stringReader3.ReadLine()) != null)
						{
							num4++;
							if (text4.Contains("CAL.Common.MASTER_KEY_ENC :"))
							{
								string[] array3 = Regex.Split(Regex.Split(text4, ":")[1], ",");
								cmkadd2 = array3[0];
							}
						}
						cmkadd = cmkadd2;
						int num5 = Convert.ToInt32(cmkadd);
						cmkprevadd = Convert.ToString(num5 + 1);
						int num6 = Convert.ToInt32(cmkprevadd);
						cmkprevadd2 = Convert.ToString(num6 + 1);
						int num7 = Convert.ToInt32(cmkprevadd2);
						cmkprevadd3 = Convert.ToString(num7 + 1);
						int num8 = Convert.ToInt32(cmkprevadd3);
						cmkprevadd4 = Convert.ToString(num8 + 1);
						int num9 = Convert.ToInt32(cmkprevadd4);
						cmkprevadd5 = Convert.ToString(num9 + 1);
					}
				}
				comisread = true;
				Thread.Sleep(1000);
			}
			catch (Exception ex)
			{
				Console.WriteLine(" Error Receiving data!");
			}
		}
		
		public static void s550tlunlock_p2()
			{
				try
				{
					if (serialPort.IsOpen)
					{
						Console.WriteLine("Enviando llaves calculadas...");
						serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmladd + ",0,1,2,0\"\r");
						Thread.Sleep(3000);
						serialPort.WriteLine("AT+NVVALUEGETINFO=\"CAL.Common.MASTER_KEY_ENC\"\r");
						Thread.Sleep(3000);
						s550tlunlock_p3();
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine(" Error 2!");
				}
			}
		
		public static void s550tlunlock_p3()
		{
			try
			{
				if (serialPort.IsOpen)
				{
					Console.WriteLine("Terminando...");
					serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmkadd + "0,32,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\"\r");
					Thread.Sleep(3000);
					serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmkprevadd + ",0,32,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\"\r");
					Thread.Sleep(3000);
					serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmkprevadd2 + ",0,32,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\"\r");
					Thread.Sleep(3000);
					serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmkprevadd3 + ",0,32,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\"\r");
					Thread.Sleep(3000);
					serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmkprevadd4 + ",0,32,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\"\r");
					Thread.Sleep(3000);
					serialPort.WriteLine("AT+NVVALUEWRITE=\"" + cmkprevadd5 + ",0,32,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0\"\r");
					Thread.Sleep(3000);
					serialPort.Close();
					Thread.Sleep(300);
					Console.Write("Done!");
				}
			}
			catch (Exception ex)
			{
				Console.Write("Error 3!");
			}
		}
	}
	
}
	