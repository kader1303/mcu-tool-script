﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using winAPIcom;
using cdmaDevLib;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;

namespace Tsendspc
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
		//	var pass = Console.ReadLine();
		//	if (pass == hash)
		//	{
				Console.WriteLine("Iniciando. . .");
				string portName = Console.ReadLine();
				cdmaTerm.Connect(portName);
				if (cdmaTerm.thePhone.LogData.Contains("opened"))
				{
					Console.WriteLine("Conectado. . .");
					string spcbyuser = Console.ReadLine();
					cdmaTerm.Q.Clear();
					cdmaTerm.SendSpc(spcbyuser);
					cdmaTerm.Q.Run();
					if (cdmaTerm.thePhone.LogData.Contains("Spc Accepted"))
					{
						Console.WriteLine("SPC Aceptado. . .");
						Thread.Sleep(1000);
						cdmaTerm.Disconnect();
					}
					else
					{
						Console.WriteLine("SPC incorrecto!");
						Thread.Sleep(1000);
						cdmaTerm.Disconnect();
					}
				}
				else
				{
					Console.WriteLine("Puerto Incorrecto");
					Thread.Sleep(1000);
					cdmaTerm.Disconnect();
				}
				Thread.Sleep(1000);
				cdmaTerm.Disconnect();	
		//	}
		//	else
		//	{
		//		Console.WriteLine("Wrong Auth");
		//	}
		Console.ReadKey();
		}
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
	
	}
	
}
