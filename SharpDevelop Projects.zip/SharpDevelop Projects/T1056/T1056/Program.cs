﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using winAPIcom;
using cdmaDevLib;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Windows.Forms;

namespace T1056
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
				Console.WriteLine("Iniciando. . .");
				string portName = Console.ReadLine();
				cdmaTerm.Connect(portName);
				if (cdmaTerm.thePhone.LogData.Contains("opened"))
				{
					Console.WriteLine("Conectado. . .");
					Thread.Sleep(500);
					cdmaTerm.readSpcFromPhone(cdmaTerm.SpcReadType.DefaultNv);
					cdmaTerm.Q.Run();
					if (cdmaTerm.thePhone.LogData.Contains("Spc not found"))
					{
						Console.WriteLine("NOT FOUND!");
						string SPC = Console.ReadLine();
						cdmaTerm.Q.Clear();
						cdmaTerm.SendSpc(SPC);
						cdmaTerm.Q.Run();
						Thread.Sleep(1000);
					}
					else if (cdmaTerm.thePhone.Spc != null) 
					{
						Console.WriteLine("SPC: " + cdmaTerm.thePhone.Spc);
						string SPC = cdmaTerm.thePhone.Spc;
						cdmaTerm.Q.Clear();
						cdmaTerm.SendSpc(SPC);
						cdmaTerm.Q.Run();
						Thread.Sleep(1000);
					}
					else 
					{
						Console.WriteLine("Sending 000000");
						string SPC = "000000";
						cdmaTerm.Q.Clear();
						cdmaTerm.SendSpc(SPC);
						cdmaTerm.Q.Run();
						Thread.Sleep(1000);
					}
					if (cdmaTerm.thePhone.LogData.Contains("Spc Accepted"))
					{
						Console.WriteLine("SPC Aceptado. . .");
						Thread.Sleep(500);
					}
					else
					{
						Console.WriteLine("SPC incorrecto!");
						Thread.Sleep(500);
					}
					string tempDirectory = PleaseCallMeSS.GetTempDirectory();
					string texto = Path.Combine(tempDirectory, "XT1056.txt");
					byte[] infogpro = GetResourceData("XT1056.txt");
					File.WriteAllBytes(texto, infogpro);
					string address = texto;
					int num = 0;
					int num2 = 0;
					int num3 = 0;
					int num4 = 0;
					StreamReader streamReader = new StreamReader(address);
					ArrayList arrayList = new ArrayList();
					long length = streamReader.BaseStream.Length;
					checked
					{
						while (streamReader.Peek() != -1)
						{
							string text = streamReader.ReadLine();
							if (text.Contains("Parameter bad"))
							{
								num++;
							}
							else if (text.Contains("Access denied"))
							{
								num2++;
							}
							else if (text.Contains("Inactive item"))
							{
								num3++;
							}
							else if (text.Contains("OK"))
							{
								num4++;
							}
							arrayList.Add(text);
						}
						streamReader.Close();
						if (Operators.ConditionalCompareObjectEqual(arrayList[0], "[NV items]", false))
						{
							int num5 = 3;
							int num6 = arrayList.Count - 1;
							for (int i = num5; i <= num6; i++)
							{
								string text2 = "";
								string text3 = "";
								int num7 = 0;
								int num8 = Conversions.ToInteger(Operators.SubtractObject(NewLateBinding.LateGet(arrayList[i], null, "IndexOf", new object[]
								{
									"("
								}, null, null, null), 1));
								for (int j = num7; j <= num8; j++)
								{
									text2 = Conversions.ToString(Operators.AddObject(text2, NewLateBinding.LateIndexGet(arrayList[i], new object[]
									{
										j
									}, null)));
								}
								if (arrayList[i].ToString().Contains("OK"))
								{
									if (arrayList[i + 1].ToString().Contains("|"))
									{
										string text4 = arrayList[i + 1].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 2].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 3].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 4].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 5].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 6].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 7].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
										text4 = arrayList[i + 8].ToString();
										text3 += text4.Remove(text4.IndexOf("|")).TrimEnd(new char[0]);
									}
									else
								{
									text3 += arrayList[i + 1].ToString();
									text3 += arrayList[i + 2].ToString();
									text3 += arrayList[i + 3].ToString();
									text3 += arrayList[i + 4].ToString();
									text3 += arrayList[i + 5].ToString();
									text3 += arrayList[i + 6].ToString();
									text3 += arrayList[i + 7].ToString();
									text3 += arrayList[i + 8].ToString();
								}
									text3 = text3.Replace(" ", "");
									string strConsoleOut = "RestoreNVItems - " + text2.ToString();
									Console.WriteLine(strConsoleOut);
									cdmaTerm.WriteNv(Conversions.ToInteger(text2), ConversionUtils.HexStringToBytes(text3));
								}
								i++;
							}
						}
						else
						{
							Console.WriteLine("Invalid NV Items file!");			
						}	
						Console.WriteLine("Done!");	
						Console.Write("Reiniciando. . .");
						var reset = new byte [] { 2, 0 }; 
						CommandQueue commandQueue = new CommandQueue();
						command = new Command(Qcdm.Cmd.DIAG_CONTROL_F, reset , "Reinico OK");
						commandQueue.Add(ref command);	
						commandQueue.Run();
						File.Delete(texto);						
					 }
				}
				else
				{
					Console.WriteLine("Puerto Incorrecto");
					Thread.Sleep(1000);
					cdmaTerm.Disconnect();
				}
				Thread.Sleep(1000);
				cdmaTerm.Disconnect();	
				
			}
			else
			{
				Console.WriteLine("Wrong Auth");
			}
		}
		
		public static Command command;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static byte[] GetResourceData(string resourceName)
	    {
	        var embeddedResource = Assembly.GetExecutingAssembly().GetManifestResourceNames().FirstOrDefault(s => string.Compare(s, resourceName, true) == 0);
	
	        if (!string.IsNullOrWhiteSpace(embeddedResource))
	        {
	            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(embeddedResource))
	            {
	                var data = new byte[stream.Length];
	                stream.Read(data, 0, data.Length);
	
	                return data;
	            }
	        }
	        else
	        {
	        	Console.WriteLine("pingon");
	        }
	
	        return null;
	    }
				
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
	
	}

	public class ConversionUtils
	{
		public static string ReverseHex(string value)
		{
			if (string.IsNullOrEmpty(value))
			{
				return string.Empty;
			}
			StringBuilder stringBuilder = new StringBuilder();
			int num = 0;
			checked
			{
				int num2 = value.Length - 2;
				for (int i = num; i <= num2; i += 2)
				{
					stringBuilder.Append(new string(value.Substring(i, 2).Reverse<char>().ToArray<char>()));
				}
				return ConversionUtils.FormatHexStr(Strings.StrReverse(stringBuilder.ToString()));
			}
		}
		
		public static string FormatHexStr(string hexStr)
		{
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				try
				{
					int num = 0;
					int num2 = hexStr.Length - 1;
					for (int i = num; i <= num2; i += 2)
					{
						stringBuilder.Append(hexStr.Substring(i, 2) + " ");
					}
				}
				catch (Exception ex)
				{
					return stringBuilder.ToString().TrimEnd(new char[0]);
				}
				return stringBuilder.ToString().TrimEnd(new char[0]);
			}
		}
		
		public static string ReverseHexToIMEI(string hexInput)
		{
			if (string.IsNullOrEmpty(hexInput))
			{
				return string.Empty;
			}
			string text = hexInput.Remove(0, 1);
			StringBuilder stringBuilder = new StringBuilder();
			int num = 1;
			checked
			{
				int num2 = text.Length - 2;
				for (int i = num; i <= num2; i += 2)
				{
					stringBuilder.Append(new string(text.Substring(i, 2).Reverse<char>().ToArray<char>()));
				}
				return stringBuilder.ToString().TrimStart(new char[]
				{
					'A'
				});
			}
		}
		
		public static byte[] HexStringToBytes(string strInput)
		{
			checked
			{
				byte[] result;
				try
				{
					int num = 0;
					int num2 = 0;
					byte[] array = new byte[(int)Math.Round(unchecked((double)strInput.Length / 2.0 - 1.0)) + 1];
					while (strInput.Length > num + 1)
					{
						long value = Convert.ToInt64(strInput.Substring(num, 2), 16);
						array[num2] = Convert.ToByte(value);
						num += 2;
						num2++;
					}
					result = array;
				}
				catch (Exception ex)
				{
					Interaction.MsgBox("Hex String To Byte Array Conversion Error!", MsgBoxStyle.Critical, null);
					result = null;
				}
				return result;
			}
		}
		
		public static string IMEIToReverseHex(string imei)
		{
			if (string.IsNullOrEmpty(imei))
			{
				return string.Empty;
			}
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				int num = imei.Length - 2;
				for (int i = 1; i <= num; i += 2)
				{
					stringBuilder.Append(new string(imei.Substring(i, 2).Reverse<char>().ToArray<char>()));
				}
				return ConversionUtils.FormatHexStr(string.Format("08{0}A{1}", imei[0], stringBuilder.ToString()));
			}
		}
	}	
	
	internal class PleaseCallMeSS
	{
		public static string GetTempDirectory()
		{
			string randomFileName = Path.GetRandomFileName();
			string text = Path.Combine(Path.GetTempPath(), randomFileName);
			Directory.CreateDirectory(text);
			return text;
		}
	}
	
}
