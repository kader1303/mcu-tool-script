﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 19/03/2020
 * Time: 07:45-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using Ionic.Zip;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;

namespace t60
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
		//	var pass = Console.ReadLine();
		//	if (pass == hash)
		//	{
				Console.WriteLine("Searching SAMSUNG Mobile USB Modem Port...");		
				string text = ModuleRAM.CheckPort();
				if (!string.IsNullOrEmpty(text))
				{
					Console.WriteLine("[" + text + "]", Color.Blue, FontStyle.Regular);
					try
					{
						Thread.Sleep(1000);
						SerialCOM.Instance(text);
						Console.WriteLine("Iniciando envio de bytes...");
						ModuleParams.MODEL = Console.ReadLine();
						ModuleParams.RAM = null;
						if (ModuleParams.MODEL.Contains("N930") || ModuleParams.MODEL.Contains("SCV34"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "52E0A4AEE786914";
							ModuleParams.PUBKEY_COUNT = "400000006D7BF67B9B39681";
						}
						else if (ModuleParams.MODEL.Contains("G930"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "2CD19D5B16B932";
							ModuleParams.PUBKEY_COUNT = "40000000171C79FB592";
						}
						else if (ModuleParams.MODEL.Contains("G935"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "CB22214B8CEBB7";
							ModuleParams.PUBKEY_COUNT = "400000002534A6915";
						}
						else if (ModuleParams.MODEL.Contains("G891"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "A48DCC2E3989BF";
							ModuleParams.PUBKEY_COUNT = "400000002FF2C789";
						}
						else if (ModuleParams.MODEL.Contains("G892"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "66AD929F2A38D";
							ModuleParams.PUBKEY_COUNT = "40000000EBD591403D5";
						}
						else if (ModuleParams.MODEL.Contains("02H") || ModuleParams.MODEL.Contains("SCV33"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "C1918938E27FE";
							ModuleParams.PUBKEY_COUNT = "400000008B420748D";
						}
						else if (ModuleParams.MODEL.Contains("G950") || ModuleParams.MODEL.Contains("02J") || ModuleParams.MODEL.Contains("SCV36"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "106539FD61AF6";
							ModuleParams.PUBKEY_COUNT = "40000000A950718E67ACD";
						}
						else if (ModuleParams.MODEL.Contains("G955") || ModuleParams.MODEL.Contains("03J"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "4C39C8A75E6";
							ModuleParams.PUBKEY_COUNT = "40000000C7A134FB09";
						}
						else if (ModuleParams.MODEL.Contains("SCV35"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "4C39C8A75E6A";
							ModuleParams.PUBKEY_COUNT = "40000000C7A134FB0";
						}
						else if (ModuleParams.MODEL.Contains("N950") || ModuleParams.MODEL.Contains("01K") || ModuleParams.MODEL.Contains("SCV37"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "2B6E3E8A44A57";
							ModuleParams.PUBKEY_COUNT = "400000009FC56C65A";
						}
						else if (ModuleParams.MODEL.Contains("J250"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "8C47BF465678EA";
							ModuleParams.PUBKEY_COUNT = "400000000B6AAB255";
						}
						else if (ModuleParams.MODEL.Contains("J415"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "8C47BF465678EA";
							ModuleParams.PUBKEY_COUNT = "400000000B6AAB255";
						}
						else if (ModuleParams.MODEL.Contains("J410"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "8C47BF465678EA";
							ModuleParams.PUBKEY_COUNT = "400000000B6AAB255";
						}
						else if (ModuleParams.MODEL.Contains("J610"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "8C47BF465678EA";
							ModuleParams.PUBKEY_COUNT = "400000000B6AAB255";
						}
						else if (ModuleParams.MODEL.Contains("J510"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "BB246BA4C8F83";
							ModuleParams.PUBKEY_COUNT = "400000005F904BAB61";
						}
						else if (ModuleParams.MODEL.Contains("J500"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "BB246BA4C8F83";
							ModuleParams.PUBKEY_COUNT = "400000005F904BAB61";
						}
						else if (ModuleParams.MODEL.Contains("J727P"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "C8CA090D55165";
							ModuleParams.PUBKEY_COUNT = "40000000EF83F280F";
						}
						else if (ModuleParams.MODEL.Contains("J327P"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "8C47BF465";
							ModuleParams.PUBKEY_COUNT = "400000000B6AAB255D";
						}
						else if (ModuleParams.MODEL.Contains("J810"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "201229DAA29D7E0";
							ModuleParams.PUBKEY_COUNT = "400000004B7EB8649D";
						}
						else if (ModuleParams.MODEL.Contains("A605"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "B8E995DAB020CE";
							ModuleParams.PUBKEY_COUNT = "40000000C35C41D11";
						}
						else if ((ModuleParams.MODEL.Contains("03K") | ModuleParams.MODEL.Contains("02K")) || ModuleParams.MODEL.Contains("SCV38") || ModuleParams.MODEL.Contains("SCV39"))
						{
							ModuleParams.PUBKEYSIGN_COUNT = "151AA1F82E80";
							ModuleParams.PUBKEY_COUNT = "40000000AD04A018D";
						}
						SerialCOM.SerialPortWrite("PrEaMbLe");
						SerialCOM.SerialPortWrite("PrObE");
						SerialCOM.SerialPortWrite("PrEaMbLe");
						if (ModuleParams.MODEL.Contains("J2") || ModuleParams.MODEL.Contains("J3") || ModuleParams.MODEL.Contains("J5") || ModuleParams.MODEL.Contains("J4") || ModuleParams.MODEL.Contains("J7") || ModuleParams.MODEL.Contains("J8") || ModuleParams.MODEL.Contains("A6"))
						{
							SerialCOM.SerialPortWrite("86000000");
							SerialCOM.SerialPortWrite("9FFFFFFF");
						}
						else if (ModuleParams.MODEL.Contains("SC-03") || ModuleParams.MODEL.Contains("SC-02J") || ModuleParams.MODEL.Contains("SC-02K") || ModuleParams.MODEL.Contains("SC-01K") || ModuleParams.MODEL.Contains("95") || ModuleParams.MODEL.Contains("96"))
						{
							SerialCOM.SerialPortWrite("8D000000");
							SerialCOM.SerialPortWrite("9FFFFFFF");
						}
						else
						{
							SerialCOM.SerialPortWrite("8b000000");
							SerialCOM.SerialPortWrite("9FFFFFFF");
						}
						Console.WriteLine("Generando Ram Dump...");
						SerialCOM.SerialPortWrite("DaTaXfEr");
						SerialCOM.binaryLength = 0;
						ModuleParams.RAM = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
						ModuleParams.DUMP = 0;
						while (SerialCOM.binaryLength <= 130000000)
						{
							Thread.Sleep(150);
							if (ModuleParams.DUMP > 0)
							{
								break;
							}
							SerialCOM.SerialPortWrite("AcKnOwLeDgMeNt");
						}
						ModuleParams.IMEISIGN = null;
						Console.WriteLine("Reiniciando a modo normal...");
						SerialCOM.SerialPortWrite("PrEaMbLe");
						SerialCOM.SerialPortWrite("1fffffffc");
						SerialCOM.SerialPortWrite("1ffffffff");
						SerialCOM.SerialPortWrite("DaTaXfEr");
						Thread.Sleep(2000);
						if (File.Exists(ModuleParams.BinaryFile()))
							{
								//new SerialCOM().ReadIMEISIGN();
								ModuleEncrypt.CryptoFile();
							}		
						else
							{
								Console.WriteLine("Fallo generando Ram Dump!");
							}
					}
					catch (Exception)
					{
						SerialCOM.binaryLength = -1;
						SerialCOM.SerialPortClose();
						Console.WriteLine("Fallo abirendo puerto!");
					}
				}
				else
				{
					Console.WriteLine("No se detecto puerto Modem!");
				}
			//}
		}
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
	}
	
	internal class SerialCOM
	{
		
		internal static void SerialPortClose()
		{
			SerialCOM.mySerialPort.DiscardInBuffer();
			SerialCOM.mySerialPort.DiscardOutBuffer();
			SerialCOM.mySerialPort.Close();
		}
		
		internal static string smethod_1(byte[] byte_0)
		{
			return new SoapHexBinary(byte_0).ToString();
		}
		
		public byte[] FileToByteArray(string fileName)
		{
			byte[] result = null;
			using (FileStream fileStream = File.OpenRead(fileName))
			{
				using (BinaryReader binaryReader = new BinaryReader(fileStream))
				{
					result = binaryReader.ReadBytes((int)fileStream.Length);
				}
			}
			return result;
		}
			
		internal static void SerialPortWrite(string Command)
		{
			SerialCOM.mySerialPort.Write(Command);
		}
		
		internal static void Instance(string PortNum)
		{
			SerialCOM.mySerialPort = new SerialPort();
			SerialCOM.mySerialPort.PortName = PortNum;
			SerialCOM.mySerialPort.BaudRate = 230400;
			SerialCOM.mySerialPort.Parity = Parity.None;
			SerialCOM.mySerialPort.DataBits = 8;
			SerialCOM.mySerialPort.StopBits = StopBits.One;
			SerialCOM.mySerialPort.RtsEnable = true;
			SerialCOM.mySerialPort.DtrEnable = true;
			SerialCOM.mySerialPort.ReadBufferSize = 26843544;
			SerialCOM.mySerialPort.DataReceived += SerialCOM.DataReceivedEventHandler;
			SerialCOM.mySerialPort.Open();
		}
		
		private static void DataReceivedEventHandler(object sender, SerialDataReceivedEventArgs e)
		{
			checked
			{
				try
				{
					byte[] array = new byte[SerialCOM.mySerialPort.BytesToRead];
					SerialCOM.mySerialPort.Read(array, 0, array.Length);
					SerialCOM.binaryLength += array.Length;
					if (SerialCOM.binaryLength >= 0)
					{
						string text = SerialCOM.smethod_1(array);
						if (text.Contains(ModuleParams.PUBKEY_COUNT))
						{
							byte[] array2 = ConversionUtils.HexStringToBytes(SerialCOM.hex1 + text);
							using (BinaryWriter binaryWriter = new BinaryWriter(File.Open(ModuleParams.BinaryFile(), FileMode.Create)))
							{
								binaryWriter.Write(array2, 0, array2.Length);
							}
							ModuleParams.DUMP = 2;
						}
						SerialCOM.hex1 = text;
					}
				}
				catch
				{
				}
			}
		}	

		private static SerialPort mySerialPort;

		internal static int binaryLength = -1;

		private static AutoResetEvent readNow = new AutoResetEvent(false);

		private List<string> list_0;

		private static string hex1;
	}
	
	public class ConversionUtils
	{
		public static byte[] HexStringToBytes(string strInput)
		{
			checked
			{
				byte[] result;
				try
				{
					int num = 0;
					int num2 = 0;
					byte[] array = new byte[(int)Math.Round(unchecked((double)strInput.Length / 2.0 - 1.0)) + 1];
					while (strInput.Length > num + 1)
					{
						long value = Convert.ToInt64(strInput.Substring(num, 2), 16);
						array[num2] = Convert.ToByte(value);
						num += 2;
						unchecked
						{
							num2++;
						}
					}
					result = array;
				}
				catch (Exception)
				{
					Interaction.MsgBox("Hex String To Byte Array Conversion Error!", MsgBoxStyle.Critical, null);
					result = null;
				}
				return result;
			}
		}
	}
	
	internal class ModuleParams
	{
		internal static string FINGERPRINT { get; set; }

		internal static string USERNAME { get; set; }

		internal static string PASSWORD { get; set; }

		internal static string ACCOUNT_LOGIN { get; set; }

		internal static int CREDIT { get; set; }

		internal static string CREDIT_WANT { get; set; }

		internal static string ACTIVE { get; set; }

		internal static string ATERROR { get; set; }

		internal static string AUTH { get; set; }

		internal static string AKSEENO { get; set; }

		internal static string MSL { get; set; }

		internal static string RAM { get; set; }

		internal static int DUMP { get; set; }

		internal static int DUMPRAMBYTE { get; set; }

		internal static string MODEL { get; set; }

		internal static string CARRIER { get; set; }
		
		internal static string IMEI { get; set; }

		internal static string UNLOCKED { get; set; }

		internal static string ABSENT { get; set; }

		internal static string READY { get; set; }

		internal static string SIMLOCK { get; set; }

		internal static string HARDWARE { get; set; }

		internal static string CheckSIMStatus { get; set; }

		internal static string KERRNEL { get; set; }

		internal static string IMEI2 { get; set; }

		internal static string SIMDSDS { get; set; }

		internal static string MEID { get; set; }
		
		internal static string SN { get; set; }

		internal static string SPC { get; set; }

		internal static string IMEISIGN { get; set; }

		internal static string KNOX { get; set; }

		internal static string ANDROIDVER { get; set; }

		internal static string IMEISIGN_NG { get; set; }

		internal static string IMEISIGN_DUAL { get; set; }

		internal static string DECRYPTO_IMEISIGN { get; set; }

		internal static string DECRYPTO_PUBKEY { get; set; }

		internal static string DECRYPTO_PUBKEYSIGN { get; set; }

		internal static string DECRYPTO_IMEI { get; set; }

		internal static string ENCRYPTO_IMEI { get; set; }

		internal static string ENCRYPTO_IMEISIGN { get; set; }

		internal static string ENCRYPTO_PUBKEY { get; set; }

		internal static string ENCRYPTO_PUBKEYSIGN { get; set; }

		internal static string ENCRYPTO_IMEI2 { get; set; }

		internal static string ENCRYPTO_IMEISIGN2 { get; set; }

		internal static string ENCRYPTO_PUBKEY2 { get; set; }

		internal static string ENCRYPTO_PUBKEYSIGN2 { get; set; }

		internal static string UN { get; set; }

		internal static string AKSEEDNO { get; set; }

		internal static int AKS { get; set; }

		internal static string DEBUG { get; set; }

		internal static string SECDUMP { get; set; }

		internal static string RAMDUMP { get; set; }

		internal static string CP_DEBUG { get; set; }

		internal static string CheckIMEI1 { get; set; }

		internal static string CheckIMEI2 { get; set; }

		internal static string ODIN { get; set; }

		internal static string DUMPNAME { get; set; }

		internal static byte[] DUMPDATA { get; set; }

		internal static string SALECODE { get; set; }

		internal static string PUBKEY_COUNT { get; set; }

		internal static string PUBKEYSIGN_COUNT { get; set; }

		internal static ArrayList ARRAYCERT { get; set; }

		internal static string BinaryFile()
		{
			return string.Concat(new object[]
			{
				ModuleParams.RAM,
				".bin"
			});
		}

		internal static string BinaryFile2()
		{
			return string.Concat(new object[]
			{
				ModuleParams.RAMDUMP,
				".bin"
			});
		}

		public static string GetTimestamp(DateTime value)
		{
			return value.ToString("yyyyMMddHHmmssffff");
		}

		public static string GetTimestamp2(DateTime value)
		{
			return value.ToString("yyyyMMddHH");
		}

		public static string timeStamp = ModuleParams.GetTimestamp(DateTime.Now);

		public static string timeStamp2 = ModuleParams.GetTimestamp2(DateTime.Now);

		internal static string LOGIN_WORK = "NOT";
		
		internal static string LOGINED = "NOT";
	}
	
	internal class ModuleEncrypt
	{
		
		public static byte[] GetPasswordBytes()
		{
			byte[] buffer = new byte[]
			{
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			};
			return SHA256.Create().ComputeHash(buffer);
		}
		
		public static void CryptoFile()
		{
			using (ZipFile zipFile = new ZipFile())
			{
				Console.WriteLine("Guardando Sec File...");
				string text = string.Concat(new string[]
				{
					Directory.GetCurrentDirectory(),
					"\\Backup\\",
					ModuleParams.MODEL,
					"_",
					ModuleParams.timeStamp,
					".bin"
				});
				if (File.Exists(text))
				{
					File.Delete(text);
				}
				File.Move(ModuleParams.BinaryFile(),text);
				if (File.Exists(text))
				{
					Console.WriteLine("Listo!");
				}
				else
				{
					Console.WriteLine("Error genearando Sec File!");
				}
			}
		}
	}
	
	internal class ModuleRAM
	{	
		private static string nada;
		
		public static string CheckPort()
		{
			for (int i = 0; i < 20; i++)
			{
				string[] portNames = SerialPort.GetPortNames();
				if (portNames.Count<string>() > 0)
				{
					foreach (string text in portNames)
					{
						if (ModuleRAM.method_4(text))
						{
							nada = text;
							return text;
						}
					}
				}
				Thread.Sleep(1000);
			}
			return nada;
		}
		
		private static bool method_4(string string_1)
		{
			bool result;
			try
			{
				if (ModuleRAM.method_5(string_1))
				{
					ModuleRAM.serialPort_0.Write("PrEaMbLe");
					Thread.Sleep(3000);
					if (ModuleRAM.serialPort_0.ReadExisting().Contains("AcKnOwLeDgMeNt"))
					{
						ModuleRAM.serialPort_0.Close();
						ModuleRAM.serialPort_0.Dispose();
						result = true;
					}
					else
					{
						result = false;
					}
				}
				else
				{
					result = false;
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}
		
		private static SerialPort serialPort_0;
		
		private static bool method_5(string string_1)
		{
			try
			{
				ModuleRAM.serialPort_0.Close();
				ModuleRAM.serialPort_0.Dispose();
			}
			catch (Exception)
			{
			}
			bool result;
			try
			{
				ModuleRAM.serialPort_0 = new SerialPort(string_1);
				ModuleRAM.serialPort_0.BaudRate = 230400;
				ModuleRAM.serialPort_0.Parity = Parity.None;
				ModuleRAM.serialPort_0.StopBits = StopBits.One;
				ModuleRAM.serialPort_0.DataBits = 8;
				ModuleRAM.serialPort_0.Handshake = Handshake.None;
				ModuleRAM.serialPort_0.RtsEnable = true;
				ModuleRAM.serialPort_0.ReadBufferSize = 214748364;
				ModuleRAM.serialPort_0.Open();
				result = true;
			}
			catch (Exception)
			{
				try
				{
					ModuleRAM.serialPort_0.Close();
					ModuleRAM.serialPort_0.Dispose();
				}
				catch (Exception)
				{
				}
				result = false;
			}
			return result;
		}
	}
	
}