﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 02/05/2020
 * Time: 03:14-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
 
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;


namespace Tmtk
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
		//	Console.WriteLine(finalString);
		//	var pass = Console.ReadLine();
		//	if (pass == hash)
		//	{
				Console.WriteLine("Iniciando ADB!");
				ModuleProcess.Instance();
				string tempDirectory = PleaseCallMeSS.GetTempDirectory();
				string texto = Path.Combine(tempDirectory, "mtk-su");
				byte[] infogpro = GetResourceData("mtk-su");
				Thread.Sleep(1000);
				File.WriteAllBytes(texto, infogpro);
				ModuleProcess.Instance();
				ModuleProcess.RunProcessTimeOut("push " + texto + " /data/local/tmp/mtk-su", -1);
				File.Delete(texto);
				ModuleProcess.Instance();
				ModuleProcess.StartProcess();
				Console.WriteLine("ok...");
				Thread.Sleep(1000);
			//	ModuleProcess.RunProcessWriteLine("cd /data/local/tmp");
			//	Thread.Sleep(1000);
				ModuleProcess.RunProcessWriteLine("chmod 755 /data/local/tmp/mtk-su");
				Thread.Sleep(1000);
				ModuleProcess.RunProcessWriteLine("/data/local/tmp/mtk-su");
				Thread.Sleep(7000);
			//	ModuleProcess.RunProcessWriteLine("./mtk-su");
			//	Thread.Sleep(7000);
				do 
				{
					Thread.Sleep(1000);
					Console.WriteLine("Type command:");
					commandos = Console.ReadLine();
					ModuleProcess.RunProcessWriteLine(commandos);
				} while (commandos != "exit");
				ModuleProcess.Instance();
				ModuleProcess.StartProcess();
				ModuleProcess.RunProcessWriteLine("rm /data/local/tmp/mtk-su");
				Console.WriteLine("Done!");
		//	}
		//	else
		//	{
		//		Console.WriteLine("Wrong Auth!");
		//	}	
		}
		
		public static byte[] GetResourceData(string resourceName)
	    {
	        var embeddedResource = Assembly.GetExecutingAssembly().GetManifestResourceNames().FirstOrDefault(s => string.Compare(s, resourceName, true) == 0);
	
	        if (!string.IsNullOrWhiteSpace(embeddedResource))
	        {
	            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(embeddedResource))
	            {
	                var data = new byte[stream.Length];
	                stream.Read(data, 0, data.Length);
	
	                return data;
	            }
	        }
	        else
	        {
	        	Console.WriteLine("pingon");
	        }
	
	        return null;
	    }
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		internal static string commandos { get; set; }	
	}
	
	public sealed class ModuleProcess
	{
		internal static void Instance()
		{
			ModuleProcess.myProcess = new Process();
			ModuleProcess.myProcess.StartInfo.UseShellExecute = false;
			ModuleProcess.myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
			ModuleProcess.myProcess.StartInfo.CreateNoWindow = true;
			ModuleProcess.myProcess.StartInfo.StandardOutputEncoding = Encoding.UTF8;
			ModuleProcess.myProcess.StartInfo.RedirectStandardOutput = true;
			ModuleProcess.myProcess.StartInfo.RedirectStandardInput = true;
			ModuleProcess.myProcess.OutputDataReceived += ModuleProcess.ReceivedEventHandler;
			ModuleProcess.myProcess.StartInfo.FileName = Application.StartupPath + "\\adb.exe";
		}
		
	//	internal static bool combinedAuth;
		
	//	internal static string combinedOutput;
		
	//	internal static string text;
		
		internal static void StartProcess()
		{
			ModuleProcess.myProcess.StartInfo.Arguments = "shell";
			ModuleProcess.myProcess.Start();
			ModuleProcess.myProcess.BeginOutputReadLine();
		}
		
		internal static void RunProcessWriteLine(string Command)
		{
			ModuleProcess.myProcess.StandardInput.WriteLine(Command);
		}
		
		internal static void RunProcessTimeOut(string Command, int iTimeout)
		{
			ModuleProcess.myProcess.StartInfo.Arguments = Command;
			ModuleProcess.myProcess.Start();
			ModuleProcess.myProcess.WaitForExit(iTimeout);
			Thread.Sleep(2000);
		}
		
		internal static string RunProcessReturnOutput(string Command)
		{
			ModuleProcess.myProcess.StartInfo.Arguments = Command;
			ModuleProcess.myProcess.Start();
			Thread.Sleep(10000);
			return ModuleProcess.myProcess.StandardOutput.ReadToEnd();
		}
		
		private static Process myProcess;
		
		private static void ReceivedEventHandler(object sender, DataReceivedEventArgs e)
		{
			if (e.Data != null)
			{
				string text = Regex.Replace(e.Data, "^\\s+$[\\r\\n]*", "", RegexOptions.Multiline);
				Console.WriteLine(text);
			}
			
		}
		
	}
	
	internal class PleaseCallMeSS
	{
		public static string GetTempDirectory()
		{
			string randomFileName = Path.GetRandomFileName();
			string text = Path.Combine(Path.GetTempPath(), randomFileName);
			Directory.CreateDirectory(text);
			return text;
		}
		
		public static string GetRandomFileName()
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			return finalString;
		}
	}
}