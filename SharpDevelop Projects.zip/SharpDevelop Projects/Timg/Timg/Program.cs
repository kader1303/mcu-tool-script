﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;
using System.Runtime.InteropServices;

namespace Timg
{
	class Program
	{
		[DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
		static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);
			
		public static void Main(string[] args)
		{
			bool dep = false;
			Process[] processlist = Process.GetProcesses();
			foreach (Process theprocess in processlist)
			{
				Process[] processes = Process.GetProcessesByName(theprocess.ProcessName);
				if (string.Equals(theprocess.ProcessName, "x64dbg", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "x32dbg", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "dnspy", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "cutter", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "ollydbg", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "myauttoexe", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "pe-bear", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "ida64", StringComparison.OrdinalIgnoreCase) || string.Equals(theprocess.ProcessName, "ida32", StringComparison.OrdinalIgnoreCase))
				{
					dep = true;
					break;
				}
			}
			if (dep == true)
			{
				Console.WriteLine("No me depures maricon!");
			}
			else if (File.Exists("C:\\Program Files\\Eltima Software\\Serial Port Monitor\\SerialMonitorx64.exe") || File.Exists("C:\\Program Files\\IDA Freeware 7.0\\ida64.exe") || File.Exists("C:\\Program Files (x86)\\IDA Freeware 7.0\\ida32.exe")  || File.Exists("C:\\Program Files\\USB Monitor Pro\\usbmonitor.exe") || File.Exists("C:\\Program Files\\HHD Software\\Device Monitoring Studio\\studio.exe") || File.Exists("C:\\Program Files (x86)\\Advanced Serial Port Monitor\\aspmon.exe"))
			{
				Console.WriteLine("Ah Cojone tu no entiendes sere!");
			}
			else
			{
				Console.WriteLine("Todo en orden");
			}
		}
	}
}