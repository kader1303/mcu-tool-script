﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 17/03/2020
 * Time: 06:12-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace t36
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
			
				SerialPort serialPort = new SerialPort();
				string text = DetectSerialPort("LGE Mobile");
				string text2 = DetectSerialPort("LGE AndroidNet USB Serial Port");
				if (!string.IsNullOrEmpty(text) || !string.IsNullOrEmpty(text2))
				{
					string portName = Regex.Split(text + text2, " ")[0].Trim();
					Console.WriteLine("[" + portName + "]");
					try
					{
						serialPort.PortName = portName;
						serialPort.BaudRate = 9600;
						serialPort.Parity = Parity.None;
						serialPort.DataBits = 8;
						serialPort.StopBits = StopBits.One;
						serialPort.RtsEnable = true;
						serialPort.DtrEnable = true;
						int millisecondsTimeout = 3000;
						serialPort.Open();
						if (serialPort.IsOpen)
						{
							Console.WriteLine("Reiniciando...");
							serialPort.BaseStream.Flush();
							byte[] array = new byte[]
							{
								58,
								0,
								0,
								24,
								51,
								126
							};
							serialPort.Write(array, 0, array.Length);
							Thread.Sleep(millisecondsTimeout);
							Console.WriteLine("OK");
							serialPort.Close();
						}
						else
						{
							Console.WriteLine("Fail to open port!\n");
						}
					}
					catch (Exception)
					{
						serialPort.Close();
						Console.WriteLine("Error!");
					}
				}
				else
				{
					Console.WriteLine("No Port!");
				}
			}
			else
			{
				Console.Write("Wrong Key!");
			}
			Console.Write("Proceso Terminado!");
		}
		
		private static string DetectSerialPort(string stringFindName)
		{
			string result = null;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				IEnumerable<string> portNames = SerialPort.GetPortNames();
				List<ManagementBaseObject> inner = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				foreach (string text in (from n in portNames
				join p in inner on n equals p["DeviceID"].ToString()
				select n + " - " + p["Caption"]).ToList<string>())
				{
					if (text.Contains(stringFindName))
					{
						result = text;
					}
				}
			}
			using (ManagementObjectSearcher managementObjectSearcher2 = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
			{
				IEnumerable<string> portNames2 = SerialPort.GetPortNames();
				IEnumerable<string> portWin10 = from p in managementObjectSearcher2.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>()
				select p["Caption"].ToString();
				portList = (from n in portNames2
				select n + " - " + portWin10.FirstOrDefault((string s) => s.Contains(n))).ToList<string>();
				foreach (string text2 in portList)
				{
					if (text2.Contains(stringFindName))
					{
						result = text2;
					}
				}
			}
			return result;
		}
		
		private static List<string> portList;
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
		
		}
	
	}
