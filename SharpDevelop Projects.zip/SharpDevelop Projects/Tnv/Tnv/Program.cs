﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 22/04/2020
 * Time: 01:34-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Collections;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using winAPIcom;
using cdmaDevLib;
using System.Globalization;
using System.Management;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Resources;

namespace Tnv
{
	class Program
	{
		public static void Main(string[] args)
		{
			var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			var stringChars = new char[10];
			string imeihex = null;
			var random = new Random();
			for (int i = 0; i < stringChars.Length; i++)
			{
			    stringChars[i] = chars[random.Next(chars.Length)];
			}	
			var finalString = new String(stringChars);
			var reverse = ReverseString(finalString);
			var hash = CreateMD5(reverse);
			Console.WriteLine(finalString);
			var pass = Console.ReadLine();
			if (pass == hash)
			{
				Console.WriteLine("Iniciando. . .");
				string portName = Console.ReadLine();
				cdmaTerm.Connect(portName);
				if (cdmaTerm.thePhone.LogData.Contains("opened"))
				{
					Console.WriteLine("Conectado. . .");
					string spcbyuser = Console.ReadLine();
					cdmaTerm.Q.Clear();
					cdmaTerm.SendSpc(spcbyuser);
					cdmaTerm.Q.Run();
					if (cdmaTerm.thePhone.LogData.Contains("Spc Accepted"))
					{
						Console.WriteLine("SPC Aceptado. . .");
						Thread.Sleep(1000);
					}
					else
					{
						Console.WriteLine("SPC incorrecto!");
						Thread.Sleep(1000);
					}
					Console.WriteLine("Leyendo. . .");
					cdmaTerm.SendTerminalCommand("262602", true);
					if (cdmaTerm.thePhone.LogData.Contains("26 26 02 08"))
					{
						var lines = cdmaTerm.thePhone.LogData.Split(new char[] {'\n'});
						var count = lines.Count();
						foreach (var item in lines)
						{
							if (item.Contains("26 26 02 08"))
							{
								imeihex = item.Substring(8,27).Replace(" ", "");
								break;
							}
						}
					}					
					bool flag = true;
					cdmaTerm.AddAllEvdo();
					cdmaTerm.AddNv(NvItems.NvItems.NV_MEID_I);
					cdmaTerm.AddQc(Qcdm.Cmd.DIAG_ESN_F);
					cdmaTerm.AddNv(NvItems.NvItems.NV_DIR_NUMBER_I);
					cdmaTerm.AddNv(NvItems.NvItems.NV_SEC_CODE_I);
					cdmaTerm.AddNv(NvItems.NvItems.NV_LOCK_CODE_I);
					cdmaTerm.AddNv(NvItems.NvItems.NV_HOME_SID_NID_I);
					cdmaTerm.AddNv(NvItems.NvItems.NV_NAM_LOCK_I);
					cdmaTerm.AddNv(NvItems.NvItems.NV_DS_QCMIP_I);
					flag = (flag && cdmaTerm.Q.Run());
					if (flag)
					{
						cdmaTerm.ReadMIN1();
					}
					if (imeihex != null)
					{
						string Text2 = ConversionUtils.ReverseHexToIMEI(imeihex).Replace(" ", "");
						Console.WriteLine("IMEI: " + Text2);
						Thread.Sleep(500);
					}
					if (cdmaTerm.thePhone.Meid != null)
					{
						Console.WriteLine("MEID: " + cdmaTerm.thePhone.Meid);
						Thread.Sleep(500);
					}		
					if (cdmaTerm.thePhone.Esn != null) 
					{
						Console.WriteLine("ESN: " + cdmaTerm.thePhone.Esn);
						Thread.Sleep(500);
					}
					if (cdmaTerm.thePhone.UserLock != null) 
					{
						Console.WriteLine("LOCK: " + cdmaTerm.thePhone.UserLock);
						Thread.Sleep(500);
					}
					if (cdmaTerm.thePhone.Spc != null) 
					{
						Console.WriteLine("SPC: " + cdmaTerm.thePhone.Spc);
						Thread.Sleep(500);
					}	
					if (cdmaTerm.thePhone.Mdn != null) 
					{
						Console.WriteLine("MDN: " + cdmaTerm.thePhone.Mdn);
						Thread.Sleep(500);
					}	
					if (cdmaTerm.thePhone.Spc != null) 
					{
						Console.WriteLine("MIN: " + cdmaTerm.thePhone.Min);
						Thread.Sleep(500);
					}	
					if (cdmaTerm.thePhone.Sid != null) 
					{
						Console.WriteLine("SID: " + cdmaTerm.thePhone.Sid);
						Thread.Sleep(500);
					}	
					if (cdmaTerm.thePhone.NamLock != null) 
					{
						Console.WriteLine("NAMLOCK: " + cdmaTerm.thePhone.NamLock);
						Thread.Sleep(500);
					}	
					if (cdmaTerm.thePhone.Qcmip != null) 
					{
						Console.WriteLine("QCMIP: " + cdmaTerm.thePhone.Qcmip);
						Thread.Sleep(500);
					}
					Console.WriteLine("Okey!");
				}
				else
				{
					Console.WriteLine("Puerto Incorrecto");
					Thread.Sleep(1000);
					cdmaTerm.Disconnect();
				}
				Thread.Sleep(1000);
				cdmaTerm.Disconnect();
		}
		else
		{
			Console.WriteLine("Wrong Auth");
		}
	}
	
		private static string portraw { get; set; }
		
		public static string CreateMD5(string input)
	    {
	        using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
	        {
	            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
	            byte[] hashBytes = md5.ComputeHash(inputBytes);
	
	            // Convert the byte array to hexadecimal string
	            StringBuilder sb = new StringBuilder();
	            for (int i = 0; i < hashBytes.Length; i++)
	            {
	                sb.Append(hashBytes[i].ToString("X2"));
	            }
	            return sb.ToString();
	        }
	    }
		
		public static string ReverseString(string s)
	    {
	        char[] arr = s.ToCharArray();
	        Array.Reverse(arr);
	        return new string(arr);
	    }
	
	}
	
	public class ConversionUtils
	{
		public static string FormatHexStr(string hexStr)
		{
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				try
				{
					int num = 0;
					int num2 = hexStr.Length - 1;
					for (int i = num; i <= num2; i += 2)
					{
						stringBuilder.Append(hexStr.Substring(i, 2) + " ");
					}
				}
				catch (Exception ex)
				{
					return stringBuilder.ToString().TrimEnd(new char[0]);
				}
				return stringBuilder.ToString().TrimEnd(new char[0]);
			}
		}
		
		public static string ReverseHexToIMEI(string hexInput)
		{
			if (string.IsNullOrEmpty(hexInput))
			{
				return string.Empty;
			}
			string text = hexInput.Remove(0, 1);
			StringBuilder stringBuilder = new StringBuilder();
			int num = 1;
			checked
			{
				int num2 = text.Length - 2;
				for (int i = num; i <= num2; i += 2)
				{
					stringBuilder.Append(new string(text.Substring(i, 2).Reverse<char>().ToArray<char>()));
				}
				return stringBuilder.ToString().TrimStart(new char[]
				{
					'A'
				});
			}
		}
		
		public static byte[] HexStringToBytes(string strInput)
		{
			checked
			{
				byte[] result;
				try
				{
					int num = 0;
					int num2 = 0;
					byte[] array = new byte[(int)Math.Round(unchecked((double)strInput.Length / 2.0 - 1.0)) + 1];
					while (strInput.Length > num + 1)
					{
						long value = Convert.ToInt64(strInput.Substring(num, 2), 16);
						array[num2] = Convert.ToByte(value);
						num += 2;
						num2++;
					}
					result = array;
				}
				catch (Exception ex)
				{
					Interaction.MsgBox("Hex String To Byte Array Conversion Error!", MsgBoxStyle.Critical, null);
					result = null;
				}
				return result;
			}
		}
		
		public static string IMEIToReverseHex(string imei)
		{
			if (string.IsNullOrEmpty(imei))
			{
				return string.Empty;
			}
			StringBuilder stringBuilder = new StringBuilder();
			checked
			{
				int num = imei.Length - 2;
				for (int i = 1; i <= num; i += 2)
				{
					stringBuilder.Append(new string(imei.Substring(i, 2).Reverse<char>().ToArray<char>()));
				}
				return ConversionUtils.FormatHexStr(string.Format("08{0}A{1}", imei[0], stringBuilder.ToString()));
			}
		}
	}	
}
