﻿/*
 * Created by SharpDevelop.
 * User: Mundo Celular
 * Date: 12/04/2020
 * Time: 07:18-
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.IO.Ports;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Threading;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Management;
using System.Text.RegularExpressions;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Resources;

namespace T69
{
	class Program
	{
		public static void Main(string[] args)
		{
		  	Console.Write("Enter Crypted Hash... ");
		 	byte[] inputBuffer = new byte[4096];
		 	Stream inputStream = Console.OpenStandardInput(inputBuffer.Length);
		 	Console.SetIn(new StreamReader(inputStream,Console.InputEncoding, false, inputBuffer.Length));
			byte[] passwordBytes = ModuleEncrypt.GetPasswordBytes();
			ModuleParams.ENCRYPTO_IMEISIGN2 = Console.ReadLine();
			ModuleParams.DECRYPTO_IMEISIGN = AES.Decrypt(ModuleParams.ENCRYPTO_IMEISIGN2, passwordBytes);
			Console.Write("Decrypted String: ");			
			Console.WriteLine(ModuleParams.DECRYPTO_IMEISIGN);			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
		
	}
	
	internal class ModuleParams
	{
		internal static string DECRYPTO_IMEISIGN { get; set; }

		internal static string ENCRYPTO_IMEISIGN2 { get; set; }
	}
	
	internal class ModuleEncrypt
		
	{
		
	public	static byte[] GetPasswordBytes()
		{
			byte[] buffer = new byte[]
			{
				1,
				2,
				3,
				4,
				5,
				6,
				7,
				8
			};
			return SHA256.Create().ComputeHash(buffer);
		}
	
	}
	
	internal class AES
	{
	
	public static string Decrypt(string decryptedText, byte[] passwordBytes)
		{
			byte[] bytesToBeDecrypted = Convert.FromBase64String(decryptedText);
			passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
			byte[] array = AES.AES_Decrypt(bytesToBeDecrypted, passwordBytes);
			int saltSize = AES.GetSaltSize(passwordBytes);
			byte[] array2 = new byte[array.Length - saltSize];
			for (int i = saltSize; i < array.Length; i++)
			{
				array2[i - saltSize] = array[i];
			}
			return Encoding.UTF8.GetString(array2);
		}
	
	public static byte[] AES_Decrypt(byte[] bytesToBeDecrypted, byte[] passwordBytes)
		{
			byte[] result = null;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (RijndaelManaged rijndaelManaged = new RijndaelManaged())
				{
					rijndaelManaged.KeySize = 256;
					rijndaelManaged.BlockSize = 128;
					Rfc2898DeriveBytes rfc2898DeriveBytes = new Rfc2898DeriveBytes(passwordBytes, passwordBytes, 1000);
					rijndaelManaged.Key = rfc2898DeriveBytes.GetBytes(rijndaelManaged.KeySize / 8);
					rijndaelManaged.IV = rfc2898DeriveBytes.GetBytes(rijndaelManaged.BlockSize / 8);
					rijndaelManaged.Mode = CipherMode.CBC;
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, rijndaelManaged.CreateDecryptor(), CryptoStreamMode.Write))
					{
						cryptoStream.Write(bytesToBeDecrypted, 0, bytesToBeDecrypted.Length);
						cryptoStream.Close();
					}
					result = memoryStream.ToArray();
				}
			}
			return result;
		}
	
	public static int GetSaltSize(byte[] passwordBytes)
		{
			byte[] bytes = new Rfc2898DeriveBytes(passwordBytes, passwordBytes, 1000).GetBytes(2);
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < bytes.Length; i++)
			{
				stringBuilder.Append(Convert.ToInt32(bytes[i]).ToString());
			}
			int num = 0;
			string text = stringBuilder.ToString();
			for (int j = 0; j < text.Length; j++)
			{
				int num2 = Convert.ToInt32(text[j].ToString());
				num += num2;
			}
			return num;
		}
	
	}
}